﻿namespace Gem
{
    internal class Truck : Vehicle
    {

        public Truck()
        {
            Console.WriteLine("Welcome To Truck Parameterless Constructor!");
        }
        public Truck(string mdl, string clr, float wth, float len,float hght, short maxSpd, string engn,float boxVol):
            base(mdl, clr, wth, len, hght, maxSpd, engn)
        {
            Console.WriteLine("Welcome To Truck Parameterless Constructor!");
            BoxVolume = boxVol;
        }
        public string GetSpecifications(string kind)
        {
            return base.GetSpecifications(kind) + "\nBox Volume\t: " + BoxVolume;
        }
        public override string ToString() 
        {
            return $"Model \t-> {Model}\nColor \t-> ({Color})\nEngine \t-> {Engine}\nBox \t->{BoxVolume} m3";
        }

        public float BoxVolume { get; set; }
        public static string Manufacturer {  get; set; }
        public static void GreetVisitor()
        {
            Console.WriteLine("Welcome to Truck!");
        }
        public override string GreetUser(string UserName) 
        { 
            return $"Hi, {UserName}. Welcome to Class Truck. Have a Happy day";
        }

    }
}
