﻿namespace Gem
{
    public partial class Customer
    {
        public string Email { get; set; }
        public string Address { get; set; }

        public override string ToString()
        {
            return $"Id\t: {Id}\nName\t: {Name}\nEmail\t: {Email}\nAddress\t: {Address}";
        }
    }
}
