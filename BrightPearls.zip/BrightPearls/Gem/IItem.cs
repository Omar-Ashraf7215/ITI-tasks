﻿
namespace Gem
{
    internal interface IItem
    {

            public int Code { get; set; }
            public string Name { get; set; }
            public DateTime ExpiryDate { get; set; }

            public string GetInfo();
        
    }
}
