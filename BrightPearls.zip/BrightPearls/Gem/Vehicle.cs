﻿namespace Gem
{
    public abstract class Vehicle
    {
        public abstract string GreetUser(string UserName);

        private string model;

        public string Model
        {
            get
            {
                if (model == null) 
                    return string.Empty;
                else
                    return"[[[" + model.ToUpper() + "]]]";
            }
            set 
            {
                if(value.ToLower().Contains("sun"))
                    Console.WriteLine("Model cannot contain 'sun' ");
                else
                model = value;
            
            }
        }

        public string Color { get; set; }
        public float Width { get; set; }
        public float Length { get; set; }
        public float Height { get; set; }
        public short MaximumSpeed { get; set; }
        public string Engine {  get; set; }

        public string GetSpecifications()
        {
            return $"Model\t\t: {Model}\nColor\t\t: {Color} " +
                $"\nWidth\t\t: {Width}\nLength\t\t: {Length}" +
                $"\nHeight\t\t: {Height}\nMaximumSpeed\t\t: {MaximumSpeed}";
        }
        #region Task
        public void SetModel(string value)
        {
            if (value.ToLower().Contains("sun"))
                Console.WriteLine("Model cannot contain 'sun'");
            else
                model = value;
        }
        public string GetModel()
        {
            if (model is null)
                return string.Empty;
            else
                return "[[[" + model.ToUpper() + "]]]";
        }
        #endregion

        public string GetSpecifications(string kind)
        {
            if (kind.ToLower() == "full")
            {
                return $"Model\t\t: {Model}\nColor\t\t: {Color}\nWidth\t\t: {Width}\nLength\t\t:{Length}\nHeight\t\t: {Height}\nMaximumSpeed\t: {MaximumSpeed}\nEngine\t\t: {Engine}";
            }
            else
            {
                return $"Model\t\t: {Model}\nColor\t\t: {Color}";
            }
        }
        public Vehicle()
        {
            Console.WriteLine("Hi from the Vehicle Class Paraneterless Constructor!");
        }

        public Vehicle(string model, string color, float width, float length,
            float height, short maximumSpeed, string engine)
        {
            Console.WriteLine("Hello from the Vehicle Class Paraneterless Constructor!");
            Model = model;
            Color = color;
            Width = width;
            Length = length;
            Height = height;
            MaximumSpeed = maximumSpeed;
            Engine = engine;
        }
            
    }
}                                            

                                                               