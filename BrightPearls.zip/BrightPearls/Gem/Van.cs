﻿//عمر اشرف محمد عبدالمجيد
//Helwan
//BIS
//Level 4
namespace Gem
{
    internal class Van : Vehicle
    {
        public override string GreetUser(string UserName)
        {
            throw new NotImplementedException();
        }
    }
}
