﻿namespace Gem
{
    internal class Bus : Vehicle
    {
        public override string GreetUser(string UserName)
        {
            throw new NotImplementedException();
        }
    }
}
