﻿namespace Gem
{
    public struct ProductDescriptionCard
    {
        public ProductDescriptionCard(string name, byte size, string color)
        {
            Name = name;
            Size = size;
            Color = color;
        }

        public string Name { get; set; }
        public byte Size { get; set; }
        public string Color { get; set; }

        public void PrintDescription()
        {
            Console.WriteLine($"\nName\t: {Name}\nSize\t: {Size}\nColor\t: {Color}");
        }
    }
}
