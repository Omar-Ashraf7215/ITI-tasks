﻿//عمر اشرف محمد عبدالمجيد
//Helwan
//BIS
//Level 4
#region
#region Day1
#region tasks
//Console.WriteLine("Our services:");
//Console.WriteLine("-Mobile Apps,");
//Console.WriteLine("-Web Devolopment,"); 
//Console.WriteLine("-Desktop Devolopment and");
//Console.WriteLine("-Custom Devolopment");


//cw --> Console.WriteLine();
//Console.WriteLine();

//string manager = "Ashraf Omar";

//Console.WriteLine("Campany Manager:" + manager);

//Console.Write("Enter ypur name: ");
//string name = Console.ReadLine();

//Console.WriteLine("Hi, " + name);


//Console.WriteLine("typeof(short):"+ typeof(short));
//Console.WriteLine("sizeof(short):"+ sizeof(short));
//Console.WriteLine("typeof(MinValue):" + short.MinValue);
//Console.WriteLine("sizeof(MaxValue):" + short.MaxValue);

//Console.WriteLine("typeof(float):" + typeof(float));
//Console.WriteLine("sizeof(float):" + sizeof(float));
//Console.WriteLine("typeof(MinValue):" + float.MinValue);
//Console.WriteLine("sizeof(MaxValue):" + float.MaxValue);
#endregion
#region Assignment
//Console.WriteLine(
//    "C# Type\t\t.Net Type\t\tSize (in byyes)\t\tRange\n" +
//    "byte\t\t" + typeof(byte) + "\t\t" + sizeof(byte) + "\t\t\t" + byte.MinValue + " to " + byte.MaxValue + "\n"+
//    "sbyte\t\t" + typeof(sbyte) + "\t\t" + sizeof(sbyte) + "\t\t\t" + sbyte.MinValue + " to " + sbyte.MaxValue + "\n"+
//    "short\t\t" + typeof(short) + "\t\t" + sizeof(short) + "\t\t\t" + short.MinValue + " to " + short.MaxValue + "\n"+
//    "ushort\t\t" + typeof(ushort) + "\t\t" + sizeof(ushort) + "\t\t\t" + ushort.MinValue + " to " + ushort.MaxValue + "\n" +
//    "int\t\t" + typeof(int) + "\t\t" + sizeof(int) + "\t\t\t" + int.MinValue + " to " + int.MaxValue + "\n" +
//    "uint\t\t" + typeof(uint) + "\t\t" + sizeof(uint) + "\t\t\t" + uint.MinValue + " to " + uint.MaxValue + "\n" +
//    "long\t\t" + typeof(long) + "\t\t" + sizeof(long) + "\t\t\t" + long.MinValue + " to " + long.MaxValue + "\n" +
//    "ulong\t\t" + typeof(ulong) + "\t\t" + sizeof(ulong) + "\t\t\t" + ulong.MinValue + " to " + ulong.MaxValue + "\n" +
//    "float\t\t" + typeof(float) + "\t\t" + sizeof(float) + "\t\t\t" + float.MinValue + " to " + float.MaxValue + "\n" +
//    "double\t\t" + typeof(double) + "\t\t" + sizeof(double) + "\t\t\t" + double.MinValue + " to " + double.MaxValue + "\n" +
//    "decimal\t\t" + typeof(decimal) + "\t\t" + sizeof(decimal) + "\t\t\t" + decimal.MinValue + " to " + decimal.MaxValue + "\n" +
//    "bool\t\t" + typeof(bool) + "\t\t" + sizeof(bool) + "\t\t\t" + "\n" +
//    "char\t\t" + typeof(char) + "\t\t" + sizeof(char) + "\t\t\t" + char.MinValue + " to " + char.MaxValue + "\n" +
//    "DateTime\t" + typeof(DateTime) + "\t\t" + "" + "\t\t\t" + DateTime.MinValue + " to " + DateTime.MaxValue + "\n" 
//    );
#endregion
#endregion
#region Day2
#region task 1

//string fullName = "Omar Ashraf Mohamed";
//char classification = 'B';
//byte panalities = 5;
//ushort daysWorked = 2958;
//decimal salary = 16500.75M;
//bool isEgyptian = true;
//DateTime datteOfBirth = new DateTime(2004, 3, 5);
//DateTime hiringDateAndTime = new DateTime(2022, 11, 29, 11, 39, 50);

//Console.WriteLine(
//    nameof(fullName) + "\t\t: " + fullName +
//    "\n" + nameof(classification) + "\t\t: " + classification +
//    "\n" + nameof(panalities) + "\t\t: " + panalities +
//    "\n" + nameof(daysWorked) + "\t\t: " + daysWorked +
//    "\n" + nameof(salary) + "\t\t\t: " + salary +
//    "\n" + nameof(isEgyptian) + "\t\t: " + isEgyptian +
//    "\n" + nameof(datteOfBirth) + "\t\t: " + datteOfBirth +
//    "\n" + nameof(hiringDateAndTime) + "\t\t: " + hiringDateAndTime 
//    );

#endregion
#region task 2
//byte x = 50;
//int y = x;
//Console.WriteLine("y: "+ y);

////long a = 175;
////short b = a;

////1-Explicit type conversion
//long firstNo = 175;
//short secondNo = (short)firstNo;
//Console.WriteLine(nameof(secondNo) + " [" + secondNo.GetType() + "]\t\t: " + secondNo);

//int thirdNo = Convert.ToInt32(firstNo);
//Console.WriteLine(nameof(thirdNo) + " [" + thirdNo.GetType() + "]\t\t: " + thirdNo);

//bool isStudent = true;
//byte isUndergraduate = Convert.ToByte(isStudent);
//Console.WriteLine(nameof(isStudent) + " [" + isStudent.GetType() + "]\t: " + isStudent);
//Console.WriteLine(nameof(isUndergraduate) + " [" + isUndergraduate.GetType() + "]\t: " + isUndergraduate);


#endregion
#region task 3
////1- conversion from string to anther type:
//string distance1 = "265000";
//string distance2 = "125000";

////convert.ToDataType(string value\variable)
//int totaldistance1 = Convert.ToInt32(distance1) + Convert.ToInt32(distance2);
//Console.WriteLine(nameof(totaldistance1) + "\t: " + totaldistance1) ;

////DataType.Parse(string value\variable)
//int totaldistance2 = int.Parse(distance1) + int.Parse(distance2);
//Console.WriteLine(nameof(totaldistance1) + "\t: " + totaldistance1);

////2- Conversion to string
////Convert.ToString(DataType value\variable)
//float Weight1 = 80.5F;
//string strWeight1 = Convert.ToString(Weight1);
//Console.WriteLine(nameof(strWeight1) + "\t" + strWeight1) ;

////DataType value\variable.ToString()
//float Weight2 = 54.5f;
//string strWeight2 = Weight2.ToString();
//Console.WriteLine(nameof(strWeight2) + "\t" + strWeight2);


#endregion
#region task 4
//using System.Globalization;
//Console.OutputEncoding = System.Text.Encoding.UTF8;
//float firstNo = 2.579F;
//Console.WriteLine(
//    "firstNo\t: " + firstNo +
//    "\nfirstNo\t: " + firstNo.ToString() +
//    "\nfirstNo.ToString(\"N0\")\t: " + firstNo.ToString("N0") +
//    "\nfirstNo.ToString(\"N1\")\t: " + firstNo.ToString("N1") +
//    "\nfirstNo.ToString(\"N2\")\t: " + firstNo.ToString("N2") +
//    "\nfirstNo.ToString(\"N2\")\t: " + firstNo.ToString("N3") +
//    "\nfirstNo.ToString(\"N3\")\t: " + firstNo.ToString("N3") +
//    "\nfirstNo.ToString(\"N4\")\t: " + firstNo.ToString("N4") +
//    "\nfirstNo.ToString(\"N5\")\t: " + firstNo.ToString("N5") +

//    "\n\nfirstNo.ToString(\"C0\")\t: " + firstNo.ToString("C0") +
//    "\nfirstNo.ToString(\"C1\")\t: " + firstNo.ToString("C1") +
//    "\nfirstNo.ToString(\"C2\")\t: " + firstNo.ToString("C2") +
//    "\nfirstNo.ToString(\"C2\")\t: " + firstNo.ToString("C3") +
//    "\nfirstNo.ToString(\"C3\")\t: " + firstNo.ToString("C3") +
//    "\nfirstNo.ToString(\"C4\")\t: " + firstNo.ToString("C4") +
//    "\nfirstNo.ToString(\"C5\")\t: " + firstNo.ToString("C5") +

//    "\n\nar-EG\t: " + firstNo.ToString("C2", CultureInfo.CreateSpecificCulture("ar-EG")) +
//    "\nar-KW\t: " + firstNo.ToString("C2", CultureInfo.CreateSpecificCulture("ar-KW")) +
//    "\nen-US\t: " + firstNo.ToString("C2", CultureInfo.CreateSpecificCulture("en-US")) +
//    "\nen-GB\t: " + firstNo.ToString("C2", CultureInfo.CreateSpecificCulture("en-GB")) +
//    "\nfr-FR\t: " + firstNo.ToString("C2", CultureInfo.CreateSpecificCulture("fr-FR")));

#endregion
#region task 5
//float secondNo = 0.268f;
//Console.WriteLine(
//    "\nsecondNo.ToString()\t\t: " + secondNo.ToString()+
//    "\nsecondNo.ToString(P)\t\t: " + secondNo.ToString("P") +
//    "\nsecondNo.ToString(P0)\t\t: " + secondNo.ToString("P0") +
//    "\nsecondNo.ToString(P1)\t\t: " + secondNo.ToString("P1") +
//    "\nsecondNo.ToString(P2)\t\t: " + secondNo.ToString("P2") +
//    "\nsecondNo.ToString(P3)\t\t: " + secondNo.ToString("P3") +
//    "\nsecondNo.ToString(P4)\t\t: " + secondNo.ToString("P4") +
//    "\nsecondNo.ToString(P5)\t\t: " + secondNo.ToString("P5") 
//    );
#endregion
#region task 6
//const string Company = "Bright Pearls";
//Company = "Bright Pearls Co.";
#endregion
#endregion
#region Day3
#region task 1
//const byte Sunday = 1;
//const byte Monday = 2;
//const byte Tuesday = 3;
//const byte Wednesday = 4;
//const byte Thursday = 5;
//const byte Friday = 6;
//const byte Saturday = 7;

//Console.WriteLine(
//    "(((((WeekDay enum)))))" +
//    "\nWeekDay.Tuesday\t\t\t: " + WeekDay. Tuesday +
//    "\n(byte)WeekDay.Tuesday\t\t\t: " + (byte)WeekDay. Tuesday +
//    "\nConvert.ToByte(WeekDay.Tuesday)\t: " + Convert.ToByte(WeekDay.Tuesday) +
//    "\n(WeekDay)3\t\t\t\t: "+ (WeekDay)3+
//    "\nWeekDay.Tuesday.GetType()\t\t:  " + WeekDay.Tuesday.GetType()+

//    "\n((((((PrimaryColor)))))"+
//    "\nPrimaryColor.Green\t\t\t: "+ PrimaryColor.Green+
//    "\n(int)PrimaryColor.Green\t\t\t: "+ (int)PrimaryColor.Green +
//    "\nConvert.ToInt32(PrimaryColor.Green)\t: " + Convert.ToInt32( PrimaryColor.Green) +
//    "\n(PrimaryColor)2\t\t\t\t: " + (PrimaryColor)2 +
//    "\nPrimaryColor.Green.GetType()\t\t:  " + PrimaryColor.Green.GetType() 

//    );

//enum WeekDay : byte
//{
//    Sunday = 1,
//    Monday = 2,
//    Tuesday = 3,
//    Wednesday = 4,
//    Thursday = 5,
//    Friday = 6,
//    Saturday = 7
//}

//enum PrimaryColor
//{
//    Red,
//    Green,
//    Blue,

//}
#endregion
#region task 2
//Console.Write("Enter the first number :");
//float firstNo = Convert.ToSingle(Console.ReadLine());

//Console.Write("Enter the second number :");
//float secondNo = float.Parse(Console.ReadLine()); //Single.parse(Console.ReadLine())

//Console.WriteLine(
//    "Addition\t: " + (firstNo+secondNo)+
//    "\nSubtraction\t: " + (firstNo-secondNo) +
//    "\nMultiplication\t: " + (firstNo*secondNo) +
//    "\nDivision\t: " + (firstNo/secondNo) +
//    "\nRemainder\t: " + (firstNo%secondNo) 
//    );
#endregion
#region task 3
//int distance = 75_000;
//Console.WriteLine("distance =75_000\t: "+distance);
//distance = 100_000;
//Console.WriteLine("distance=100_000\t: " + distance);
//// += Addition 
//distance += 50_000;
//Console.WriteLine("distance +=50_000\t: "+ distance);
//// -=
//distance -= 10_000;
//Console.WriteLine("distance -=10_000\t: " + distance);
//// *=
//distance *= 2;
//Console.WriteLine("distance *=2\t\t: " + distance);
//// /=
//distance /= 4;
//Console.WriteLine("distance /=4\t\t: " + distance);
#endregion
#region task 4
//Console.WriteLine("((((Prefix increment Operator))))");
//int firstNo = 125_000;
//Console.WriteLine("firstNo\t\t: "+ firstNo);
//Console.WriteLine("++firstNo\t: "+ ++firstNo);//125001
//Console.WriteLine("firstNo\t\t: "+ firstNo); //125001

//Console.WriteLine("\n((((Prefix increment Operator))))");
//int secondNo = 175_000;
//Console.WriteLine("secondNo\t: " + secondNo);
//Console.WriteLine("secondNo++\t: " + secondNo++);//175000
//Console.WriteLine("secondNo\t: " + secondNo);//175001

//Console.WriteLine("\n((((Prefix Decrement Operator))))");
//int thirdNo = 200_000;
//Console.WriteLine("thirdNo\t\t: " + thirdNo);
//Console.WriteLine("--thirdNo\t: " + --thirdNo);//199999
//Console.WriteLine("thirdNo\t\t: " + thirdNo);//199999

//Console.WriteLine("\n((((Prefix Decrement Operator))))");
//int fourthNo = 250_000;
//Console.WriteLine("fourthNo\t: " + fourthNo);
//Console.WriteLine("fourthNo--\t: " + fourthNo--);//250000
//Console.WriteLine("fourthNo\t: " + fourthNo);//249999
#endregion
#region task 5
//for(; ; )
//{
//    Console.WriteLine("\nEnter your age: " );
//    byte age=Convert.ToByte( Console.ReadLine() );
//    Console.WriteLine("Age:" + (age>=18));
//    Console.WriteLine("Enter your forign Language(E,F):");
//    char forignLanguage = char.Parse( Console.ReadLine() );
//    Console.WriteLine("English:"+(forignLanguage == 'E'));
//    Console.WriteLine("French:"+(forignLanguage == 'F'));
//}

#endregion
#region task 6
//while (true)
//{
//    Console.WriteLine("\nEnter your age: ");
//    byte age = byte.Parse(Console.ReadLine());
//    Console.WriteLine("Age:" + (age >= 18 && age <=45));

//    Console.WriteLine("Enter your forign Language(E,F):");
//    char forignLanguage = Convert.ToChar(Console.ReadLine());
//    Console.WriteLine("Forign Language:" + 
//        (forignLanguage == 'E'|| forignLanguage == 'F'));

//    Console.WriteLine("Have you ever applied for this job before (y/n)? ");
//    char appliedBefor = Convert.ToChar(Console.ReadLine());
//    Console.WriteLine("New Applicant: " + !(appliedBefor == 'y'));

//}
#endregion
#endregion
#region Day4
#region task 1
//Method (Function)
//decimal CalculatePrice(decimal cost, decimal shipping) //pascal Case & verb
//{
//    return cost * 1.2m + cost * shipping;
//}
//decimal product1Price = CalculatePrice(1000, 0.30m);
//decimal product2Price = CalculatePrice(2000, 0.20m);
//decimal product3Price = CalculatePrice(6000, 0.10m);
//Console.WriteLine(nameof(product1Price)+ "\t: " +product1Price);
//Console.WriteLine(nameof(product2Price)+ "\t: " +product2Price);
//Console.WriteLine(nameof(product3Price)+ "\t: " +product3Price);
//Console.WriteLine();

//Console.WriteLine("CalculatePrice(1000, 0.30m)\t: " + CalculatePrice(1000, 0.30m));
//Console.WriteLine("CalculatePrice(2000, 0.20m)\t: " + CalculatePrice(2000, 0.20m));
//Console.WriteLine("CalculatePrice(6000, 0.10m)\t: " + CalculatePrice(6000, 0.10m));

//void RemindUpdatePassword(string name)
//{
//    Console.WriteLine("\nHi, "+name+ "\nPlease update your password. ");
//}
//Console.WriteLine();
//RemindUpdatePassword("Ahmed Saad Ali");
//RemindUpdatePassword("Wael Omar Ashraf");

//void GreetVistor()
//{
//    Console.WriteLine("\nWelcome to Bright Pearls!");
//}
//GreetVistor();
#endregion
#region task 2
//void ShowDetails(string fullName, string nationality = "Egyptian")
//{
//    Console.WriteLine("Full Name\t: "+ fullName + "\nNationality\t: "+nationality);
//}

//ShowDetails("Omar Ashraf", "Kuwaiti");
//ShowDetails("Ayman Ashraf", "Egyptian");
//ShowDetails("Yassin Ashraf");
//ShowDetails("Hossam Hasan");

//ShowDetails(fullName: "Wael Saad", nationality: "Sudenese");
//ShowDetails(nationality: "Omani", fullName: "Hassan Omar");




#endregion
#region task 3

//decimal CalculateNetSalary(decimal basicSalary, decimal additions, decimal deductions) => basicSalary + additions - deductions;
//Console.WriteLine("CalculateNetSalary(12000m, 8000m, 5000m): " + CalculateNetSalary(12000m, 8000m, 5000m));

//void GreetUser(string username) => Console.WriteLine("Hi, " + username);
//GreetUser("Ahmed Essam");

//Console.WriteLine("Math.Sqrt(81)\t\t :  "+ Math.Sqrt(81));//9
//Console.WriteLine("Math.Cbrt(64)\t\t :  " + Math.Cbrt(64));//4
//Console.WriteLine("Math.Pow(5,3)\t\t :  "+ Math.Pow(5,3));//125
//Console.WriteLine("Math.Abs(-57)\t\t :  "+ Math.Abs(-57));//57
//Console.WriteLine("Math.Ceiling(3.7)\t :  " + Math.Ceiling(3.7));//4
//Console.WriteLine("Math.Floor(3.7)\t\t :  "+ Math.Floor(3.7));//3

//Console.WriteLine();

//Console.WriteLine("Math.Sin(90* Math.PI / 100)\t:  "+ Math.Sin(90 * Math.PI / 100));
//Console.WriteLine("Math.Cos(90* Math.PI / 100)\t:  "+ Math.Cos(90 * Math.PI / 100));
//Console.WriteLine("Math.Tan(90* Math.PI / 100)\t:  "+ Math.Tan(90 * Math.PI / 100));
#endregion
#region task 4

//for (; ; )
//{
//    Console.Write("Enter score: ");
//    float score = float.Parse(Console.ReadLine());

//    if (score >= 95) Console.WriteLine("Excellence Gift: 2000 EGP");

//    Console.Write("Status: ");
//    if (score >= 50)
//        Console.WriteLine("Passed");
//    else
//        Console.WriteLine("Failed");

//    int currentHour = DateTime.Now.Hour;

//    if (currentHour >= 4 && currentHour < 12)
//    {
//        Console.WriteLine("Good Morning");
//    }
//    else if (currentHour >= 12 && currentHour < 20)
//    {
//        Console.WriteLine("Good Afternoon");
//    }
//    else
//    {
//        Console.WriteLine("Good evening");
//    }
//}


#endregion
#region task 5
//while (true)
//{
//    Console.Write("\nEnter score: ");
//    float score = Convert.ToSingle(Console.ReadLine());
//    string studentStatus = score >= 50 ? "Passed" : "Failed";
//    Console.WriteLine("Status\t: " + studentStatus);
//    string studentGrade = score >= 90 ? "Perfrct" :
//                            score >= 80 ? "Very Good" :
//                                score >= 65 ? "Good" :
//                                    score >= 50 ? "Passed" :
//                                        score >= 40 ? "Poor" : "Very Poor";
//    Console.WriteLine("Grade\t: " + studentGrade);
//}

#endregion
#region task 6
//for (; ; )
//{
//    Console.Write("\nWhere are you from? ");
//    string country = Console.ReadLine();
//    float discountRatio;

//    switch (country)
//    {
//        case "Egypt":
//            discountRatio = 0.30f;
//            break;
//        case "Kuwait":
//            discountRatio = 0.25f;
//            break;
//        case "Libya":
//        case "Murtitania":
//        case "Tunisia":
//        case "Algeria":
//        case "Morocco":
//            discountRatio = 0.20f;
//            break;
//        default:
//            discountRatio = 0.10f;
//            break;
//    }
//    Console.WriteLine("Discount Ratio: " + discountRatio.ToString("P0"));
//}
#endregion
#region task 7
//while (true) 
//{
//    Console.Write("\nWhere are you from? ");
//    string country = Console.ReadLine();
//    float discountRatio = country switch
//    {
//        "Egypt" => 0.30f,
//        "Kuwait" => 0.25f,
//        "Libya" or "Murtitania" or "Tunisia" or "Algeria" or "Morocco" => 0.20f,
//         _ =>0.10f
//    };
//    Console.WriteLine("Discount Ratio: " + discountRatio.ToString("P0"));
//}
#endregion
#region task 8
//while (true)
//{
//    Console.Write("\nEnter score\t: ");
//    float score = Convert.ToSingle(Console.ReadLine());

//    string grade = score switch
//    {
//        >= 90 => "Perfect",
//        >= 80 => "Very Good",
//        >= 65 => "Good",
//        >= 50 => "Passed",
//        >= 40 => "Poor",
//        _ => "Very Poor",
//    };
//    Console.WriteLine("Grade\t\t: " + grade);
//}
#endregion
#endregion

#region Day 5
#region task 1
//Console.WriteLine("for (int i = 0; i < 5; i++):");
//for (int i = 0; i < 5; i++)
//{
//    Console.WriteLine(i+1+". Welcome to for loop. i: "+i+"("+DateTime.Now+")"); 
//}
//Console.WriteLine("for (int i = 1; i < 5; i++):");
//for (int i = 1; i < 5; i++)
//{
//    Console.WriteLine(i +  ". Welcome to for loop. i: " + i + "(" + DateTime.Now + ")");
//}
//Console.WriteLine("for (int i = 0; i < 5; i++):");
//for (int i = 5; i >=1 ; i--)
//{
//    Console.WriteLine(i + ". Welcome to for loop. i: " + i + "(" + DateTime.Now + ")");
//}

#endregion
#region task 2
//for (int i = 0; i < 10; i++)
//{
//    Console.WriteLine("i befor break\t: "+i);
//    if (i == 3) break;
//    Console.WriteLine("i after break\t: "+i);
//}
//Console.WriteLine();
//for (int i = 1 ;i <= 10; i++)
//{
//    Console.WriteLine("i befor continue\t: " + i);
//    if (i % 3 ==0) break;
//    Console.WriteLine("i after continue\t: " + i);
//}

#endregion
#region task 3
//for(int i =0, j = 10; i + j <= 20; i++, j++)
//{
//    Console.WriteLine("i+j: " + i + " + " + j + " = "+(i + j));
//}

//for(int i = 0; i<=12; i++)
//{
//    Console.WriteLine("\nMultiplication Table" + i + ":");

//    for (int j = 1; j <= 12; j++)
//    {
//        Console.WriteLine(i+" * " + j + " = " + (i * j));
//    }
//}
#endregion
#region task 4
//string allproducts = "\nOrder items";

//Console.WriteLine("Enter a prouduct name (when finished enter done):");
//for (string product = string.Empty; product != "done";)
//{
//    product = Console.ReadLine();
//    if(product != "done")
//    {
//        allproducts += "\n- " + product;
//    }

//}
//Console.WriteLine(allproducts);

#endregion
#region task 5
//string iti = "MCIT ITI";

//foreach (char item in iti)
//{
//    Console.WriteLine("\t|" + item + "|");
//}
#endregion
#region task 6
//byte age;
//float distance;
//string country;
//var section7Student = 50;
//var asiaPopulation = 3500_000_000;
//var worldPopulation = 6_000_000_000;
//var weigt = 75.3;
//var city = "cairo";
//var classification = 'B';
//var isStudent = false;

//string iti = "MCIT ITI";
//foreach (var item in iti)
//{
//    Console.WriteLine("\t|" + item + "|");
//}
#endregion
#region task 7
//string password = string.Empty;

//while (password != "Omar15%")
//{
//    Console.WriteLine("Enter your password: ");
//    password = Console.ReadLine();
//}
//Console.WriteLine("Welcome to Bright Pearls!");
#endregion
#region task 8
//char answer ='\0';

//do
//{
//    Console.WriteLine("\n Trying to connect to the external server...");

//    Thread.Sleep(5000);
//    Console.WriteLine("Connection failed. Retry (y/n)?");
//    answer = Convert.ToChar(Console.ReadLine());
//}
//while (answer == 'y' || answer == 'Y');
#endregion
#region task 9
//int[] week1Production;

//week1Production = new int[5];

//week1Production[0] = 21;
//week1Production[1] = 11;
//week1Production[2] = 51;
//week1Production[3] = 41;
//week1Production[4] = 31;

//int[] week2Production = new int[5] { 22, 12, 52, 42, 32 };
//int[] week3Production = new int[] { 23, 13, 53, 43, 33 };
//int[] week4Production = { 24, 14, 21, 11, 34 };

//Console.WriteLine("week4Production[2]\t" + week4Production[2]);
//week4Production[2] = 71;
//Console.WriteLine("week4Production[2]\t" + week4Production[2]);
//Console.WriteLine("week4Production.Length\t" + week4Production.Length);

//Console.WriteLine("\n(((" + nameof(week4Production) + "{foreach})))");

//foreach (var item in week4Production)
//{
//    Console.WriteLine(item);
//}
//Console.WriteLine("\n(((" + nameof(week4Production) + "{for})))");
//for (int i = 0; i < week4Production.Length; i++)
//{
//    Console.WriteLine("week4Production[" + i + "]\t" + week4Production[i]); 
//}

#endregion
#region task 10
int[] week4Production = { 24, 14, 21, 11, 34 };
Console.WriteLine("(((int[] week4Production  = { 24, 14, 21, 11, 34 } )))" );
Console.WriteLine();
Console.WriteLine("week4Production.Sum()\t\t: " + week4Production.Sum());
Console.WriteLine("week4Production.Count()\t\t: " + week4Production.Count());
Console.WriteLine("week4Production.Average()\t: " + week4Production.Average());
Console.WriteLine("week4Production.Max()\t\t: " + week4Production.Max());
Console.WriteLine("week4Production.Min()\t\t: " + week4Production.Min());
int[] week5Production = { 25, 15, 25, 15, 35 };
Console.WriteLine("(((int[] week5Production  = { 25, 15, 25, 15, 35 } )))");
Console.WriteLine();
Console.WriteLine("week5Production.Contains(15)\t\t: " + week5Production.Contains(15));
Console.WriteLine("week5Production.Contains(92)\t\t: " + week5Production.Contains(92));
Console.WriteLine();
Console.WriteLine("Array.IndexOf(week5Production, 15)\t: " + Array.IndexOf(week5Production, 15));
Console.WriteLine("Array.IndexOf(week5Production, 92)\t: " + Array.IndexOf(week5Production, 92));
Console.WriteLine("Array.LastIndexOf(week5Production, 15)\t: " + Array.LastIndexOf(week5Production, 15));
Console.WriteLine("Array.LastIndexOf(week5Production, 92)\t: " + Array.LastIndexOf(week5Production, 92));
Console.WriteLine();
Console.WriteLine("week5Production.Max()\t\t\t: " + week5Production.Max());
Console.WriteLine("Array.IndexOf(week5Production, week5Production.Max()): " 
                                                    + Array.IndexOf(week5Production, week5Production.Max()));
Console.WriteLine("week5Production.Min()\t\t\t: " + week5Production.Min());
Console.WriteLine("Array.IndexOf(week5Production, week5Production.Min()): "
                                                    + Array.IndexOf(week5Production, week5Production.Min()));
Console.WriteLine("Array.LastIndexOf(week5Production, week5Production.Min()): " + 
                                                        Array.LastIndexOf(week5Production, week5Production.Min()));
#endregion
#endregion
#endregion