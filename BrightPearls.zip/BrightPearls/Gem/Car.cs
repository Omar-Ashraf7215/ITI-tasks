﻿namespace Gem
{
    internal class Car : Vehicle
    {
        public override string GreetUser(string UserName)
        {
            throw new NotImplementedException();
        }
    }
}
