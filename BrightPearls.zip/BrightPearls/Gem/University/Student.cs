﻿namespace Gem.University
{
    internal class Student
    {
    }
}
