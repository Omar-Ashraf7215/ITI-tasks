﻿
namespace Gem
{
    public static class Utility
    {
        public static string HeadOffAddress {  get; set; }
        public static void PrintDate()
        {
            Console.WriteLine(DateTime.Today.ToLongDateString());
        }
    }
}
