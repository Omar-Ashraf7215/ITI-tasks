﻿//عمر اشرف محمد عبدالمجيد
//Helwan
//BIS
//Level 4
using Gem;
#region
#region Day1
#region tasks
//Console.WriteLine("Our services:");
//Console.WriteLine("-Mobile Apps,");
//Console.WriteLine("-Web Devolopment,"); 
//Console.WriteLine("-Desktop Devolopment and");
//Console.WriteLine("-Custom Devolopment");


//cw --> Console.WriteLine();
//Console.WriteLine();

//string manager = "Ashraf Omar";

//Console.WriteLine("Campany Manager:" + manager);

//Console.Write("Enter ypur name: ");
//string name = Console.ReadLine();

//Console.WriteLine("Hi, " + name);


//Console.WriteLine("typeof(short):"+ typeof(short));
//Console.WriteLine("sizeof(short):"+ sizeof(short));
//Console.WriteLine("typeof(MinValue):" + short.MinValue);
//Console.WriteLine("sizeof(MaxValue):" + short.MaxValue);

//Console.WriteLine("typeof(float):" + typeof(float));
//Console.WriteLine("sizeof(float):" + sizeof(float));
//Console.WriteLine("typeof(MinValue):" + float.MinValue);
//Console.WriteLine("sizeof(MaxValue):" + float.MaxValue);
#endregion
#region Assignment
//Console.WriteLine(
//    "C# Type\t\t.Net Type\t\tSize (in byyes)\t\tRange\n" +
//    "byte\t\t" + typeof(byte) + "\t\t" + sizeof(byte) + "\t\t\t" + byte.MinValue + " to " + byte.MaxValue + "\n"+
//    "sbyte\t\t" + typeof(sbyte) + "\t\t" + sizeof(sbyte) + "\t\t\t" + sbyte.MinValue + " to " + sbyte.MaxValue + "\n"+
//    "short\t\t" + typeof(short) + "\t\t" + sizeof(short) + "\t\t\t" + short.MinValue + " to " + short.MaxValue + "\n"+
//    "ushort\t\t" + typeof(ushort) + "\t\t" + sizeof(ushort) + "\t\t\t" + ushort.MinValue + " to " + ushort.MaxValue + "\n" +
//    "int\t\t" + typeof(int) + "\t\t" + sizeof(int) + "\t\t\t" + int.MinValue + " to " + int.MaxValue + "\n" +
//    "uint\t\t" + typeof(uint) + "\t\t" + sizeof(uint) + "\t\t\t" + uint.MinValue + " to " + uint.MaxValue + "\n" +
//    "long\t\t" + typeof(long) + "\t\t" + sizeof(long) + "\t\t\t" + long.MinValue + " to " + long.MaxValue + "\n" +
//    "ulong\t\t" + typeof(ulong) + "\t\t" + sizeof(ulong) + "\t\t\t" + ulong.MinValue + " to " + ulong.MaxValue + "\n" +
//    "float\t\t" + typeof(float) + "\t\t" + sizeof(float) + "\t\t\t" + float.MinValue + " to " + float.MaxValue + "\n" +
//    "double\t\t" + typeof(double) + "\t\t" + sizeof(double) + "\t\t\t" + double.MinValue + " to " + double.MaxValue + "\n" +
//    "decimal\t\t" + typeof(decimal) + "\t\t" + sizeof(decimal) + "\t\t\t" + decimal.MinValue + " to " + decimal.MaxValue + "\n" +
//    "bool\t\t" + typeof(bool) + "\t\t" + sizeof(bool) + "\t\t\t" + "\n" +
//    "char\t\t" + typeof(char) + "\t\t" + sizeof(char) + "\t\t\t" + char.MinValue + " to " + char.MaxValue + "\n" +
//    "DateTime\t" + typeof(DateTime) + "\t\t" + "" + "\t\t\t" + DateTime.MinValue + " to " + DateTime.MaxValue + "\n" 
//    );
#endregion
#endregion
#region Day2
#region task 1

//string fullName = "Omar Ashraf Mohamed";
//char classification = 'B';
//byte panalities = 5;
//ushort daysWorked = 2958;
//decimal salary = 16500.75M;
//bool isEgyptian = true;
//DateTime datteOfBirth = new DateTime(2004, 3, 5);
//DateTime hiringDateAndTime = new DateTime(2022, 11, 29, 11, 39, 50);

//Console.WriteLine(
//    nameof(fullName) + "\t\t: " + fullName +
//    "\n" + nameof(classification) + "\t\t: " + classification +
//    "\n" + nameof(panalities) + "\t\t: " + panalities +
//    "\n" + nameof(daysWorked) + "\t\t: " + daysWorked +
//    "\n" + nameof(salary) + "\t\t\t: " + salary +
//    "\n" + nameof(isEgyptian) + "\t\t: " + isEgyptian +
//    "\n" + nameof(datteOfBirth) + "\t\t: " + datteOfBirth +
//    "\n" + nameof(hiringDateAndTime) + "\t\t: " + hiringDateAndTime 
//    );

#endregion
#region task 2
//byte x = 50;
//int y = x;
//Console.WriteLine("y: "+ y);

////long a = 175;
////short b = a;

////1-Explicit type conversion
//long firstNo = 175;
//short secondNo = (short)firstNo;
//Console.WriteLine(nameof(secondNo) + " [" + secondNo.GetType() + "]\t\t: " + secondNo);

//int thirdNo = Convert.ToInt32(firstNo);
//Console.WriteLine(nameof(thirdNo) + " [" + thirdNo.GetType() + "]\t\t: " + thirdNo);

//bool isStudent = true;
//byte isUndergraduate = Convert.ToByte(isStudent);
//Console.WriteLine(nameof(isStudent) + " [" + isStudent.GetType() + "]\t: " + isStudent);
//Console.WriteLine(nameof(isUndergraduate) + " [" + isUndergraduate.GetType() + "]\t: " + isUndergraduate);


#endregion
#region task 3
////1- conversion from string to anther type:
//string distance1 = "265000";
//string distance2 = "125000";

////convert.ToDataType(string value\variable)
//int totaldistance1 = Convert.ToInt32(distance1) + Convert.ToInt32(distance2);
//Console.WriteLine(nameof(totaldistance1) + "\t: " + totaldistance1) ;

////DataType.Parse(string value\variable)
//int totaldistance2 = int.Parse(distance1) + int.Parse(distance2);
//Console.WriteLine(nameof(totaldistance1) + "\t: " + totaldistance1);

////2- Conversion to string
////Convert.ToString(DataType value\variable)
//float Weight1 = 80.5F;
//string strWeight1 = Convert.ToString(Weight1);
//Console.WriteLine(nameof(strWeight1) + "\t" + strWeight1) ;

////DataType value\variable.ToString()
//float Weight2 = 54.5f;
//string strWeight2 = Weight2.ToString();
//Console.WriteLine(nameof(strWeight2) + "\t" + strWeight2);


#endregion
#region task 4
//using System.Globalization;
//Console.OutputEncoding = System.Text.Encoding.UTF8;
//float firstNo = 2.579F;
//Console.WriteLine(
//    "firstNo\t: " + firstNo +
//    "\nfirstNo\t: " + firstNo.ToString() +
//    "\nfirstNo.ToString(\"N0\")\t: " + firstNo.ToString("N0") +
//    "\nfirstNo.ToString(\"N1\")\t: " + firstNo.ToString("N1") +
//    "\nfirstNo.ToString(\"N2\")\t: " + firstNo.ToString("N2") +
//    "\nfirstNo.ToString(\"N2\")\t: " + firstNo.ToString("N3") +
//    "\nfirstNo.ToString(\"N3\")\t: " + firstNo.ToString("N3") +
//    "\nfirstNo.ToString(\"N4\")\t: " + firstNo.ToString("N4") +
//    "\nfirstNo.ToString(\"N5\")\t: " + firstNo.ToString("N5") +

//    "\n\nfirstNo.ToString(\"C0\")\t: " + firstNo.ToString("C0") +
//    "\nfirstNo.ToString(\"C1\")\t: " + firstNo.ToString("C1") +
//    "\nfirstNo.ToString(\"C2\")\t: " + firstNo.ToString("C2") +
//    "\nfirstNo.ToString(\"C2\")\t: " + firstNo.ToString("C3") +
//    "\nfirstNo.ToString(\"C3\")\t: " + firstNo.ToString("C3") +
//    "\nfirstNo.ToString(\"C4\")\t: " + firstNo.ToString("C4") +
//    "\nfirstNo.ToString(\"C5\")\t: " + firstNo.ToString("C5") +

//    "\n\nar-EG\t: " + firstNo.ToString("C2", CultureInfo.CreateSpecificCulture("ar-EG")) +
//    "\nar-KW\t: " + firstNo.ToString("C2", CultureInfo.CreateSpecificCulture("ar-KW")) +
//    "\nen-US\t: " + firstNo.ToString("C2", CultureInfo.CreateSpecificCulture("en-US")) +
//    "\nen-GB\t: " + firstNo.ToString("C2", CultureInfo.CreateSpecificCulture("en-GB")) +
//    "\nfr-FR\t: " + firstNo.ToString("C2", CultureInfo.CreateSpecificCulture("fr-FR")));

#endregion
#region task 5
//float secondNo = 0.268f;
//Console.WriteLine(
//    "\nsecondNo.ToString()\t\t: " + secondNo.ToString()+
//    "\nsecondNo.ToString(P)\t\t: " + secondNo.ToString("P") +
//    "\nsecondNo.ToString(P0)\t\t: " + secondNo.ToString("P0") +
//    "\nsecondNo.ToString(P1)\t\t: " + secondNo.ToString("P1") +
//    "\nsecondNo.ToString(P2)\t\t: " + secondNo.ToString("P2") +
//    "\nsecondNo.ToString(P3)\t\t: " + secondNo.ToString("P3") +
//    "\nsecondNo.ToString(P4)\t\t: " + secondNo.ToString("P4") +
//    "\nsecondNo.ToString(P5)\t\t: " + secondNo.ToString("P5") 
//    );
#endregion
#region task 6
//const string Company = "Bright Pearls";
//Company = "Bright Pearls Co.";
#endregion
#endregion
#region Day3
#region task 1
//const byte Sunday = 1;
//const byte Monday = 2;
//const byte Tuesday = 3;
//const byte Wednesday = 4;
//const byte Thursday = 5;
//const byte Friday = 6;
//const byte Saturday = 7;

//Console.WriteLine(
//    "(((((WeekDay enum)))))" +
//    "\nWeekDay.Tuesday\t\t\t: " + WeekDay. Tuesday +
//    "\n(byte)WeekDay.Tuesday\t\t\t: " + (byte)WeekDay. Tuesday +
//    "\nConvert.ToByte(WeekDay.Tuesday)\t: " + Convert.ToByte(WeekDay.Tuesday) +
//    "\n(WeekDay)3\t\t\t\t: "+ (WeekDay)3+
//    "\nWeekDay.Tuesday.GetType()\t\t:  " + WeekDay.Tuesday.GetType()+

//    "\n((((((PrimaryColor)))))"+
//    "\nPrimaryColor.Green\t\t\t: "+ PrimaryColor.Green+
//    "\n(int)PrimaryColor.Green\t\t\t: "+ (int)PrimaryColor.Green +
//    "\nConvert.ToInt32(PrimaryColor.Green)\t: " + Convert.ToInt32( PrimaryColor.Green) +
//    "\n(PrimaryColor)2\t\t\t\t: " + (PrimaryColor)2 +
//    "\nPrimaryColor.Green.GetType()\t\t:  " + PrimaryColor.Green.GetType() 

//    );

//enum WeekDay : byte
//{
//    Sunday = 1,
//    Monday = 2,
//    Tuesday = 3,
//    Wednesday = 4,
//    Thursday = 5,
//    Friday = 6,
//    Saturday = 7
//}

//enum PrimaryColor
//{
//    Red,
//    Green,
//    Blue,

//}
#endregion
#region task 2
//Console.Write("Enter the first number :");
//float firstNo = Convert.ToSingle(Console.ReadLine());

//Console.Write("Enter the second number :");
//float secondNo = float.Parse(Console.ReadLine()); //Single.parse(Console.ReadLine())

//Console.WriteLine(
//    "Addition\t: " + (firstNo+secondNo)+
//    "\nSubtraction\t: " + (firstNo-secondNo) +
//    "\nMultiplication\t: " + (firstNo*secondNo) +
//    "\nDivision\t: " + (firstNo/secondNo) +
//    "\nRemainder\t: " + (firstNo%secondNo) 
//    );
#endregion
#region task 3
//int distance = 75_000;
//Console.WriteLine("distance =75_000\t: "+distance);
//distance = 100_000;
//Console.WriteLine("distance=100_000\t: " + distance);
//// += Addition 
//distance += 50_000;
//Console.WriteLine("distance +=50_000\t: "+ distance);
//// -=
//distance -= 10_000;
//Console.WriteLine("distance -=10_000\t: " + distance);
//// *=
//distance *= 2;
//Console.WriteLine("distance *=2\t\t: " + distance);
//// /=
//distance /= 4;
//Console.WriteLine("distance /=4\t\t: " + distance);
#endregion
#region task 4
//Console.WriteLine("((((Prefix increment Operator))))");
//int firstNo = 125_000;
//Console.WriteLine("firstNo\t\t: "+ firstNo);
//Console.WriteLine("++firstNo\t: "+ ++firstNo);//125001
//Console.WriteLine("firstNo\t\t: "+ firstNo); //125001

//Console.WriteLine("\n((((Prefix increment Operator))))");
//int secondNo = 175_000;
//Console.WriteLine("secondNo\t: " + secondNo);
//Console.WriteLine("secondNo++\t: " + secondNo++);//175000
//Console.WriteLine("secondNo\t: " + secondNo);//175001

//Console.WriteLine("\n((((Prefix Decrement Operator))))");
//int thirdNo = 200_000;
//Console.WriteLine("thirdNo\t\t: " + thirdNo);
//Console.WriteLine("--thirdNo\t: " + --thirdNo);//199999
//Console.WriteLine("thirdNo\t\t: " + thirdNo);//199999

//Console.WriteLine("\n((((Prefix Decrement Operator))))");
//int fourthNo = 250_000;
//Console.WriteLine("fourthNo\t: " + fourthNo);
//Console.WriteLine("fourthNo--\t: " + fourthNo--);//250000
//Console.WriteLine("fourthNo\t: " + fourthNo);//249999
#endregion
#region task 5
//for(; ; )
//{
//    Console.WriteLine("\nEnter your age: " );
//    byte age=Convert.ToByte( Console.ReadLine() );
//    Console.WriteLine("Age:" + (age>=18));
//    Console.WriteLine("Enter your forign Language(E,F):");
//    char forignLanguage = char.Parse( Console.ReadLine() );
//    Console.WriteLine("English:"+(forignLanguage == 'E'));
//    Console.WriteLine("French:"+(forignLanguage == 'F'));
//}

#endregion
#region task 6
//while (true)
//{
//    Console.WriteLine("\nEnter your age: ");
//    byte age = byte.Parse(Console.ReadLine());
//    Console.WriteLine("Age:" + (age >= 18 && age <=45));

//    Console.WriteLine("Enter your forign Language(E,F):");
//    char forignLanguage = Convert.ToChar(Console.ReadLine());
//    Console.WriteLine("Forign Language:" + 
//        (forignLanguage == 'E'|| forignLanguage == 'F'));

//    Console.WriteLine("Have you ever applied for this job before (y/n)? ");
//    char appliedBefor = Convert.ToChar(Console.ReadLine());
//    Console.WriteLine("New Applicant: " + !(appliedBefor == 'y'));

//}
#endregion
#endregion
#region Day4
#region task 1
//Method (Function)
//decimal CalculatePrice(decimal cost, decimal shipping) //pascal Case & verb
//{
//    return cost * 1.2m + cost * shipping;
//}
//decimal product1Price = CalculatePrice(1000, 0.30m);
//decimal product2Price = CalculatePrice(2000, 0.20m);
//decimal product3Price = CalculatePrice(6000, 0.10m);
//Console.WriteLine(nameof(product1Price)+ "\t: " +product1Price);
//Console.WriteLine(nameof(product2Price)+ "\t: " +product2Price);
//Console.WriteLine(nameof(product3Price)+ "\t: " +product3Price);
//Console.WriteLine();

//Console.WriteLine("CalculatePrice(1000, 0.30m)\t: " + CalculatePrice(1000, 0.30m));
//Console.WriteLine("CalculatePrice(2000, 0.20m)\t: " + CalculatePrice(2000, 0.20m));
//Console.WriteLine("CalculatePrice(6000, 0.10m)\t: " + CalculatePrice(6000, 0.10m));

//void RemindUpdatePassword(string name)
//{
//    Console.WriteLine("\nHi, "+name+ "\nPlease update your password. ");
//}
//Console.WriteLine();
//RemindUpdatePassword("Ahmed Saad Ali");
//RemindUpdatePassword("Wael Omar Ashraf");

//void GreetVistor()
//{
//    Console.WriteLine("\nWelcome to Bright Pearls!");
//}
//GreetVistor();
#endregion
#region task 2
//void ShowDetails(string fullName, string nationality = "Egyptian")
//{
//    Console.WriteLine("Full Name\t: "+ fullName + "\nNationality\t: "+nationality);
//}

//ShowDetails("Omar Ashraf", "Kuwaiti");
//ShowDetails("Ayman Ashraf", "Egyptian");
//ShowDetails("Yassin Ashraf");
//ShowDetails("Hossam Hasan");

//ShowDetails(fullName: "Wael Saad", nationality: "Sudenese");
//ShowDetails(nationality: "Omani", fullName: "Hassan Omar");




#endregion
#region task 3

//decimal CalculateNetSalary(decimal basicSalary, decimal additions, decimal deductions) => basicSalary + additions - deductions;
//Console.WriteLine("CalculateNetSalary(12000m, 8000m, 5000m): " + CalculateNetSalary(12000m, 8000m, 5000m));

//void GreetUser(string username) => Console.WriteLine("Hi, " + username);
//GreetUser("Ahmed Essam");

//Console.WriteLine("Math.Sqrt(81)\t\t :  "+ Math.Sqrt(81));//9
//Console.WriteLine("Math.Cbrt(64)\t\t :  " + Math.Cbrt(64));//4
//Console.WriteLine("Math.Pow(5,3)\t\t :  "+ Math.Pow(5,3));//125
//Console.WriteLine("Math.Abs(-57)\t\t :  "+ Math.Abs(-57));//57
//Console.WriteLine("Math.Ceiling(3.7)\t :  " + Math.Ceiling(3.7));//4
//Console.WriteLine("Math.Floor(3.7)\t\t :  "+ Math.Floor(3.7));//3

//Console.WriteLine();

//Console.WriteLine("Math.Sin(90* Math.PI / 100)\t:  "+ Math.Sin(90 * Math.PI / 100));
//Console.WriteLine("Math.Cos(90* Math.PI / 100)\t:  "+ Math.Cos(90 * Math.PI / 100));
//Console.WriteLine("Math.Tan(90* Math.PI / 100)\t:  "+ Math.Tan(90 * Math.PI / 100));
#endregion
#region task 4

//for (; ; )
//{
//    Console.Write("Enter score: ");
//    float score = float.Parse(Console.ReadLine());

//    if (score >= 95) Console.WriteLine("Excellence Gift: 2000 EGP");

//    Console.Write("Status: ");
//    if (score >= 50)
//        Console.WriteLine("Passed");
//    else
//        Console.WriteLine("Failed");

//    int currentHour = DateTime.Now.Hour;

//    if (currentHour >= 4 && currentHour < 12)
//    {
//        Console.WriteLine("Good Morning");
//    }
//    else if (currentHour >= 12 && currentHour < 20)
//    {
//        Console.WriteLine("Good Afternoon");
//    }
//    else
//    {
//        Console.WriteLine("Good evening");
//    }
//}


#endregion
#region task 5
//while (true)
//{
//    Console.Write("\nEnter score: ");
//    float score = Convert.ToSingle(Console.ReadLine());
//    string studentStatus = score >= 50 ? "Passed" : "Failed";
//    Console.WriteLine("Status\t: " + studentStatus);
//    string studentGrade = score >= 90 ? "Perfrct" :
//                            score >= 80 ? "Very Good" :
//                                score >= 65 ? "Good" :
//                                    score >= 50 ? "Passed" :
//                                        score >= 40 ? "Poor" : "Very Poor";
//    Console.WriteLine("Grade\t: " + studentGrade);
//}

#endregion
#region task 6
//for (; ; )
//{
//    Console.Write("\nWhere are you from? ");
//    string country = Console.ReadLine();
//    float discountRatio;

//    switch (country)
//    {
//        case "Egypt":
//            discountRatio = 0.30f;
//            break;
//        case "Kuwait":
//            discountRatio = 0.25f;
//            break;
//        case "Libya":
//        case "Murtitania":
//        case "Tunisia":
//        case "Algeria":
//        case "Morocco":
//            discountRatio = 0.20f;
//            break;
//        default:
//            discountRatio = 0.10f;
//            break;
//    }
//    Console.WriteLine("Discount Ratio: " + discountRatio.ToString("P0"));
//}
#endregion
#region task 7
//while (true) 
//{
//    Console.Write("\nWhere are you from? ");
//    string country = Console.ReadLine();
//    float discountRatio = country switch
//    {
//        "Egypt" => 0.30f,
//        "Kuwait" => 0.25f,
//        "Libya" or "Murtitania" or "Tunisia" or "Algeria" or "Morocco" => 0.20f,
//         _ =>0.10f
//    };
//    Console.WriteLine("Discount Ratio: " + discountRatio.ToString("P0"));
//}
#endregion
#region task 8
//while (true)
//{
//    Console.Write("\nEnter score\t: ");
//    float score = Convert.ToSingle(Console.ReadLine());

//    string grade = score switch
//    {
//        >= 90 => "Perfect",
//        >= 80 => "Very Good",
//        >= 65 => "Good",
//        >= 50 => "Passed",
//        >= 40 => "Poor",
//        _ => "Very Poor",
//    };
//    Console.WriteLine("Grade\t\t: " + grade);
//}
#endregion
#endregion
#region Day5
#region task 1
//Console.WriteLine("for (int i = 0; i < 5; i++):");
//for (int i = 0; i < 5; i++)
//{
//    Console.WriteLine(i+1+". Welcome to for loop. i: "+i+"("+DateTime.Now+")"); 
//}
//Console.WriteLine("for (int i = 1; i < 5; i++):");
//for (int i = 1; i < 5; i++)
//{
//    Console.WriteLine(i +  ". Welcome to for loop. i: " + i + "(" + DateTime.Now + ")");
//}
//Console.WriteLine("for (int i = 0; i < 5; i++):");
//for (int i = 5; i >=1 ; i--)
//{
//    Console.WriteLine(i + ". Welcome to for loop. i: " + i + "(" + DateTime.Now + ")");
//}

#endregion
#region task 2
//for (int i = 0; i < 10; i++)
//{
//    Console.WriteLine("i befor break\t: "+i);
//    if (i == 3) break;
//    Console.WriteLine("i after break\t: "+i);
//}
//Console.WriteLine();
//for (int i = 1 ;i <= 10; i++)
//{
//    Console.WriteLine("i befor continue\t: " + i);
//    if (i % 3 ==0) break;
//    Console.WriteLine("i after continue\t: " + i);
//}

#endregion
#region task 3
//for(int i =0, j = 10; i + j <= 20; i++, j++)
//{
//    Console.WriteLine("i+j: " + i + " + " + j + " = "+(i + j));
//}

//for(int i = 0; i<=12; i++)
//{
//    Console.WriteLine("\nMultiplication Table" + i + ":");

//    for (int j = 1; j <= 12; j++)
//    {
//        Console.WriteLine(i+" * " + j + " = " + (i * j));
//    }
//}
#endregion
#region task 4
//string allproducts = "\nOrder items";

//Console.WriteLine("Enter a prouduct name (when finished enter done):");
//for (string product = string.Empty; product != "done";)
//{
//    product = Console.ReadLine();
//    if(product != "done")
//    {
//        allproducts += "\n- " + product;
//    }

//}
//Console.WriteLine(allproducts);

#endregion
#region task 5
//string iti = "MCIT ITI";

//foreach (char item in iti)
//{
//    Console.WriteLine("\t|" + item + "|");
//}
#endregion
#region task 6
//byte age;
//float distance;
//string country;
//var section7Student = 50;
//var asiaPopulation = 3500_000_000;
//var worldPopulation = 6_000_000_000;
//var weigt = 75.3;
//var city = "cairo";
//var classification = 'B';
//var isStudent = false;

//string iti = "MCIT ITI";
//foreach (var item in iti)
//{
//    Console.WriteLine("\t|" + item + "|");
//}
#endregion
#region task 7
//string password = string.Empty;

//while (password != "Omar15%")
//{
//    Console.WriteLine("Enter your password: ");
//    password = Console.ReadLine();
//}
//Console.WriteLine("Welcome to Bright Pearls!");
#endregion
#region task 8
//char answer ='\0';

//do
//{
//    Console.WriteLine("\n Trying to connect to the external server...");

//    Thread.Sleep(5000);
//    Console.WriteLine("Connection failed. Retry (y/n)?");
//    answer = Convert.ToChar(Console.ReadLine());
//}
//while (answer == 'y' || answer == 'Y');
#endregion
#region task 9
//int[] week1Production;

//week1Production = new int[5];

//week1Production[0] = 21;
//week1Production[1] = 11;
//week1Production[2] = 51;
//week1Production[3] = 41;
//week1Production[4] = 31;

//int[] week2Production = new int[5] { 22, 12, 52, 42, 32 };
//int[] week3Production = new int[] { 23, 13, 53, 43, 33 };
//int[] week4Production = { 24, 14, 21, 11, 34 };

//Console.WriteLine("week4Production[2]\t" + week4Production[2]);
//week4Production[2] = 71;
//Console.WriteLine("week4Production[2]\t" + week4Production[2]);
//Console.WriteLine("week4Production.Length\t" + week4Production.Length);

//Console.WriteLine("\n(((" + nameof(week4Production) + "{foreach})))");

//foreach (var item in week4Production)
//{
//    Console.WriteLine(item);
//}
//Console.WriteLine("\n(((" + nameof(week4Production) + "{for})))");
//for (int i = 0; i < week4Production.Length; i++)
//{
//    Console.WriteLine("week4Production[" + i + "]\t" + week4Production[i]); 
//}

#endregion
#region task 10
//int[] week4Production = { 24, 14, 21, 11, 34 };
//Console.WriteLine("(((int[] week4Production  = { 24, 14, 21, 11, 34 } )))" );
//Console.WriteLine();
//Console.WriteLine("week4Production.Sum()\t\t: " + week4Production.Sum());
//Console.WriteLine("week4Production.Count()\t\t: " + week4Production.Count());
//Console.WriteLine("week4Production.Average()\t: " + week4Production.Average());
//Console.WriteLine("week4Production.Max()\t\t: " + week4Production.Max());
//Console.WriteLine("week4Production.Min()\t\t: " + week4Production.Min());
//int[] week5Production = { 25, 15, 25, 15, 35 };
//Console.WriteLine("(((int[] week5Production  = { 25, 15, 25, 15, 35 } )))");
//Console.WriteLine();
//Console.WriteLine("week5Production.Contains(15)\t\t: " + week5Production.Contains(15));
//Console.WriteLine("week5Production.Contains(92)\t\t: " + week5Production.Contains(92));
//Console.WriteLine();
//Console.WriteLine("Array.IndexOf(week5Production, 15)\t: " + Array.IndexOf(week5Production, 15));
//Console.WriteLine("Array.IndexOf(week5Production, 92)\t: " + Array.IndexOf(week5Production, 92));
//Console.WriteLine("Array.LastIndexOf(week5Production, 15)\t: " + Array.LastIndexOf(week5Production, 15));
//Console.WriteLine("Array.LastIndexOf(week5Production, 92)\t: " + Array.LastIndexOf(week5Production, 92));
//Console.WriteLine();
//Console.WriteLine("week5Production.Max()\t\t\t: " + week5Production.Max());
//Console.WriteLine("Array.IndexOf(week5Production, week5Production.Max()): " 
//                                                    + Array.IndexOf(week5Production, week5Production.Max()));
//Console.WriteLine("week5Production.Min()\t\t\t: " + week5Production.Min());
//Console.WriteLine("Array.IndexOf(week5Production, week5Production.Min()): "
//                                                    + Array.IndexOf(week5Production, week5Production.Min()));
//Console.WriteLine("Array.LastIndexOf(week5Production, week5Production.Min()): " + 
//                                                        Array.LastIndexOf(week5Production, week5Production.Min()));
#endregion
#endregion
#region Day6
#region task1
//int[] week1Production ={ 21, 11, 51, 41, 31 };
//Console.WriteLine("int [] week1Production ={ 21, 11, 51, 41, 31 }");

//Array.Sort(week1Production);
//Console.WriteLine("week1Production after Sort():");
//foreach (var item in week1Production)
//{
//    Console.WriteLine(item);
//}
//int[] week2Production = { 22, 12, 52, 42, 32 };
//Array.Reverse(week2Production);
//Console.WriteLine("\nint[] week2Production = { 22, 12, 52, 42, 32 };");
//Console.WriteLine("week2Production after Reverse():");
//foreach (var item in week2Production)
//{
//    Console.WriteLine(item);
//}
//int[] week3Production = { 23, 13, 53, 43, 33 };
//Array.Sort(week3Production);
//Array.Reverse(week3Production);
//Console.WriteLine("\nint[] week3Production = { 23, 13, 53, 43, 33 };");
//Console.WriteLine("week3Production after Sort() and Reverse():");
//foreach (var item in week3Production)
//{
//    Console.WriteLine(item);
//}
#endregion
#region task2
//int[] week1Production = { 21, 11, 51, 41, 31 };
//int[] week2Production = { 22, 12, 52, 42, 32 };
//int[] week3Production = { 23, 13, 53, 43, 33 };
//var week4Production = new int[] { 24, 14, 54, 44, 34 };

//int[] testProduction = new int[10];
//Array.Copy(week1Production, 1, testProduction, 6, 3);
//Console.WriteLine("Array.Copy(week1Production, 1, testProduction, 6, 3);");
//for (int i = 0; i < testProduction.Length; i++)
//{
//    Console.WriteLine("testProduction[" + i + "]\t: " + testProduction[i]);
//}

//int[] augustProduction = new int[20];

//Array.Copy(week1Production, 0, augustProduction, 0, 5);
//Array.Copy(week2Production, 0, augustProduction, 5, 5);
//Array.Copy(week3Production, 0, augustProduction, 10, week4Production.Length);
//Array.Copy(week4Production, 0, augustProduction, 15, week4Production.Length);

//Console.WriteLine("\n(((" + nameof(augustProduction) + ")))");
//for (int i = 0; i < augustProduction.Length; i++)
//{
//    Console.WriteLine("augustProduction[" + i + "]\t: " + augustProduction[i]);
//}
//Console.WriteLine("\nArray.Clear(augustProduction):");
//Array.Clear(augustProduction);
//for (int i = 0;i< augustProduction.Length; i++)
//{
//    Console.WriteLine("augustProduction[" + i + "]\t: " + augustProduction[i]);
//}

#endregion
#region task3
//decimal CalculateNetProfit(decimal[] sales)
//{
//    decimal netProfit = 0m;
//    foreach (var item in sales)
//        netProfit += item * 0.25m;
//    return netProfit;
//}
//decimal[] weekSales = { 100m, 60m, 80m, 100m, 80m };
//decimal week1NetProfit = CalculateNetProfit(weekSales);
//Console.WriteLine("decimal[] weekSales = { 100m, 60m, 80m, 100m, 80m };");
//Console.WriteLine("CalculateNetProfitUsingArray(weekSales)");
//Console.WriteLine(nameof(week1NetProfit)+ ": "+week1NetProfit);

//decimal CalculateNetProfitUsingParams(params decimal[] sales)
//{
//    decimal netProfit = 0m;
//    foreach (var item in sales)
//        netProfit += item * 0.25m;
//    return netProfit;
//}
//decimal week2NetProfit = CalculateNetProfitUsingParams(120m,80m,100m);
//Console.WriteLine("\nCalculateNetProfitUsingParams(120m,80m, 100m)");
//Console.WriteLine(nameof(week2NetProfit)+ "\t: " + week2NetProfit);

#endregion
#region task4
//using System.Collections;

//ArrayList score = new ArrayList() { 75, 98.5, "Link" };
//Console.WriteLine("score.Count\t\t\t: " + score.Count);
//Console.WriteLine("score[1]\t\t\t: " + score[1]);
//score[1] = 94.25;
//Console.WriteLine("score[1]= 94.25;");
//Console.WriteLine("score[1]\t\t\t: "+ score[1]);

//Console.WriteLine("scores[scores.Count - 1]\t: "+ score[score.Count - 1]);
//Console.WriteLine("All Scores Items/Elements:");
//for (int i = 0; i < score.Count; i++)
//{
//    Console.WriteLine("scores[" + i + "]\t: " + score[i]);
//}
//ArrayList allBranches = new ArrayList() { "Egypt", "Oman", "Kuwait", "Bahrain" };
//allBranches.Add("KSA");
//allBranches.Add("UAE");
//allBranches.Add("Morocco");

//Console.WriteLine("\n(((All Branches)))");
//foreach (var branch in allBranches)
//{
//    Console.WriteLine("- " + branch);
//}


#endregion
#region task5
//Queue<string> waitingCustomers = new Queue<string>();
//waitingCustomers.Enqueue("Lotus Group");
//waitingCustomers.Enqueue("Nile Hospitals");
//waitingCustomers.Enqueue("Future Uni");
//waitingCustomers.Enqueue("Surise School");

//Console.WriteLine(nameof(waitingCustomers)+ ":");
//foreach (var customer in waitingCustomers)
//{
//    Console.WriteLine(customer);
//}

//waitingCustomers.Dequeue();
//Console.WriteLine("\n" + nameof(waitingCustomers)+ "after Dequeue()1");
//foreach (var customer in waitingCustomers)
//{
//    Console.WriteLine(customer);
//}
//waitingCustomers.Dequeue();
//Console.WriteLine("\n" + nameof(waitingCustomers) + "after Dequeue()2");
//foreach (var customer in waitingCustomers)
//{
//    Console.WriteLine(customer);
//}
#endregion
#region task6
//Stack<string> inboxMassages = new Stack<string>();
//inboxMassages.Push("Lotus Group [11:30 AM]");
//inboxMassages.Push("Nile Hospitals [12:15 PM]");
//inboxMassages.Push("Future Uni [02:38 PM]");


//Console.WriteLine("\n"+nameof(inboxMassages) + ":");
//foreach (var massage in inboxMassages)
//{
//    Console.WriteLine(massage);
//}

//inboxMassages.Pop();
//Console.WriteLine("\n" + nameof(inboxMassages) + "after Dequeue()1");
//foreach (var massage in inboxMassages)
//{
//    Console.WriteLine(massage);
//}
//inboxMassages.Pop();
//Console.WriteLine("\n" + nameof(inboxMassages) + "after Dequeue()2");
//foreach (var massage in inboxMassages)
//{
//    Console.WriteLine(massage);
//}
#endregion
#region task7
//List<string> allProducts = new List<string>() { "SIS", "ERP", "HMRS" };
//allProducts.Add("HIS");
//allProducts.Add("CRM");

//List<string> kwaitProducts = new List<string>() { "Abc", "Def" };
//allProducts.AddRange(kwaitProducts);

//string[] omanproducts = { "Ghi", "Jkl" };
//allProducts.AddRange(omanproducts);

//allProducts.AddRange(new List<string>() { "Mno", "Pql" });
//allProducts.AddRange(new List<string>() { "Stu", "Vwx" });

//Console.WriteLine("allProducts[2]: " + allProducts[2]);
//allProducts[2] = "HRIS";
//Console.WriteLine("allProducts[2]: " + allProducts[2]);

//Console.WriteLine("allProducts.Count: " + allProducts.Count);
//Console.WriteLine("allProducts.Count(): " + allProducts.Count());

//Console.WriteLine("\n(((All Products [for])))");
//for (int i = 0; i < allProducts.Count; i++)
//{
//    Console.WriteLine("allProducts[" + i + "]\t" + allProducts[i]);
//}
//Console.WriteLine("\n(((All Products [foreach])))");
//foreach (var product in allProducts)
//{
//    Console.WriteLine("- " + product);
//}

#endregion
#region task8
//string[] productsArray = allProducts.ToArray();
//Console.WriteLine("\n" + nameof(productsArray) + ":");
//foreach (var product in productsArray)
//{
//    Console.WriteLine("= " + product);
//}
#endregion
#region task9
//string[] continentsArray = { "Africa", "Asia", "Europe", "North America", "South America", "Antarcatica" };
//List<string> continentsList = continentsArray.ToList();
//Console.WriteLine("\n" + nameof(continentsList)+ ":");
//foreach(var continent in continentsList)
//{
//    Console.WriteLine("- " + continent);
//}
//Console.WriteLine("continentsList.Contains(\"Europe\")\t: " + continentsList.Contains("Europe"));
//Console.WriteLine("continentsList.Contains(\"Red Sea\")\t: " + continentsList.Contains("Red Sea"));

//Console.WriteLine("continentsList.IndexOf(\"Europe\")\t: " + continentsList.IndexOf("Europe"));
//Console.WriteLine("continentsList.IndexOf(\"Red Sea\")\t: " + continentsList.IndexOf("Red Sea"));

//Console.WriteLine("continentsList.LastIndexOf(\"Europe\")\t: " + continentsList.LastIndexOf("Europe"));
//Console.WriteLine("continentsList.LastIndexOf(\"Red Sea\")\t: " + continentsList.LastIndexOf("Red Sea"));

//continentsList.Remove("North America");
//continentsList.RemoveAt(1);

//continentsList.RemoveRange(1, 2);
//Console.WriteLine("\n" + nameof(continentsList) + "After remove:");
//foreach(var continent in continentsList)
//{
//    Console.WriteLine("= " + continent);
//}

#endregion
#endregion
#region Day7
#region task1
//Dictionary<int, string> allBranches = new Dictionary<int, string>()
//{
//    {1010,"Kuwait" },
//    {1020,"Bahrain" },
//    {2010,"Thailand" },
//    {2020,"China" }
//};
//allBranches.Add(3010, "England");
//allBranches.Add(3020, "France");

//Console.WriteLine("allBranches[1020]:"+allBranches[1020]);
//allBranches[1020] = "Oman";
//Console.WriteLine("(((allBraches[1020] = \"Oman\":)))");
//Console.WriteLine("allBranches[1020]:" + allBranches[1020]);

//Console.WriteLine("\n (((" + nameof(allBranches)+")))");
//foreach(var branch in allBranches)
//{
//    Console.WriteLine(branch.Key + ": " + branch.Value);
//}
//var chinaBranch = new KeyValuePair<int, string>(2020, "China");
//Console.WriteLine("(((var chinaBranch = new KeyValuePair<int, string>(2020, \"China\")))");
//Console.WriteLine("allBranches.Contains(chinaBranch)\t:"+ allBranches.Contains(chinaBranch));
//Console.WriteLine("allBranches.Contains(new KeyValuePair<int, string>(2020,\"China\"\t: " + 
//                                    allBranches.Contains(new KeyValuePair<int, string>(2020,"China")));

//Console.WriteLine("allBranches.ContainsKey(1020)\t\t: " + allBranches.ContainsKey(1020));
//Console.WriteLine("allBranches.ContainsKey(1030)\t\t: " + allBranches.ContainsKey(1030));

//Console.WriteLine("allBranches.ContainsValue(\"Thailand\")\t: " + allBranches.ContainsValue("Thailand"));
//Console.WriteLine("allBranches.ContainsValue(\"Japan\")\t: " + allBranches.ContainsValue("Japan"));

//allBranches.Remove(3010);
//Console.WriteLine("\n(((allBranchrs.Remove(3010);)))");
//foreach(var branch in allBranches)
//{
//    Console.WriteLine(branch.Key + ": " + branch.Value);
//}
//allBranches.Clear();
//Console.WriteLine("\n(((allBranchrs.Clear();)))");
//foreach (var branch in allBranches)
//{
//    Console.WriteLine(branch.Key + ": " + branch.Value);
//}

#endregion
#region task2
//for(; ; )
//{
//    Console.WriteLine("\nEnter a character: ");
//    char userCharacter = Convert.ToChar( Console.ReadLine());

//    Console.WriteLine(
//        "\nuserCharacter\t\t\t\t: " + userCharacter +
//        "\nchar.IsWhiteSpace(userCharacter)\t" + char.IsWhiteSpace(userCharacter) +
//        "\nchar.IsUpper(userCharacter)\t" + char.IsUpper(userCharacter) +
//        "\nchar.IsLower(userCharacter)\t" + char.IsLower(userCharacter) +
//        "\nchar.IsLetter(userCharacter)\t" + char.IsLetter(userCharacter) +
//        "\nchar.IsDigit(userCharacter)\t" + char.IsDigit(userCharacter) +
//        "\nchar.IsLetterOrDigit(userCharacter)\t" + char.IsLetterOrDigit(userCharacter) +
//        "\nchar.IsPunctuation(userCharacter)\t" + char.IsPunctuation(userCharacter) +
//        "\nchar.IsSeparator(userCharacter)\t" + char.IsSeparator(userCharacter));


//}

#endregion
#region task3
//string firstName = "Omar";
//string lastName = "Ashraf";

//Console.WriteLine("\n1. String Concatenation");
//string fullName1 ="Full Name: " + firstName + " "+ lastName;
//Console.WriteLine(fullName1);

//Console.WriteLine("\n2. String Interpolation");
//string fullName2 = $"Full Name: {firstName} {lastName}";
//Console.WriteLine(fullName2);

//Console.WriteLine("3. Verbatim String");
//string normalPath = "\\E:\\Omar\\bank\\cover\"50\".pdf";
//Console.WriteLine("normalPath");
//Console.WriteLine(normalPath);

//string verbatimStringPath = @"\E:\Omar\bank\cover\""50\"".pdf";
//Console.WriteLine("\nverbatimStringPath:");
//Console.WriteLine(verbatimStringPath);

//string verbatimStringEmployees =
//@"Full Name     Age     Position
//Ayman Ashraf    24      Developer
//Omar Ashraf     21      Senior Developer
//Wael Mahmoud    32      Team Leader";

//Console.WriteLine("\nverbatimStringEmployees:");
//Console.WriteLine(verbatimStringEmployees);






#endregion
#region task4
//string rawStringPath = """
//    \E:\Omar\bank\cover\"50\".pdf
//    """;
//Console.WriteLine("\nrawStringPath");
//Console.WriteLine(rawStringPath);

//string rawStringEmployees = """
//    Full Name       Age     Position
//    Ayman Ashraf    24      Developer
//    Omar Ashraf     21      Senior Developer
//    Wael Mahmoud    32      Team Leader
//    """;

//Console.WriteLine("\nrawStringEmployees");
//Console.WriteLine(rawStringEmployees);

#endregion
#region task5
//string firstName = "Omar";
//string lastName = "Ashraf";

//string interpolationCurlyBraces1 =$"{firstName}{lastName}{{2,9,5}}";
//Console.WriteLine("interpolationCurlyBraces1");
//Console.WriteLine(interpolationCurlyBraces1);

//string VerbatimStringVariableOrConstantValues = $@"Full Name: {firstName}{lastName} - Score: {{2,9,5}} ";
//Console.WriteLine("VerbatimStringVariableOrConstantValues"); 
//Console.WriteLine(VerbatimStringVariableOrConstantValues);

//string VerbatimStringVariableOrConstantValues01 = $"""
//    Full Name {firstName}{lastName}
//    """;
//Console.WriteLine("VerbatimStringVariableOrConstantValues01");
//Console.WriteLine(VerbatimStringVariableOrConstantValues01);

//string VerbatimStringVariableOrConstantValues02 = $$"""
//    Full Name {{firstName}}{{lastName}} - Score: {2,9,5}
//    """;
//Console.WriteLine("VerbatimStringVariableOrConstantValues02");
//Console.WriteLine(VerbatimStringVariableOrConstantValues02);

//string VerbatimStringVariableOrConstantValues03 = $$$"""
//    Full Name {{{firstName}}}{{{lastName}}} - Score: {2,9,5}
//    """;
//Console.WriteLine("VerbatimStringVariableOrConstantValues03");
//Console.WriteLine(VerbatimStringVariableOrConstantValues03);


#endregion
#region task6
//string iti = "Information Technology Institute";
//Console.WriteLine(
//    "iti\t\t\t: " + iti +
//    "\niti.StartsWith('I')\t" + iti.StartsWith('I') +
//    "\niti.StartsWith('i')\t" + iti.StartsWith('i') +

//    "\niti.StartsWith(\"I\")\t" + iti.StartsWith('I') +
//    "\niti.StartsWith(\"i\")\t" + iti.StartsWith('i') +

//    "\niti.StartsWith(\"In\")\t" + iti.StartsWith("In") +
//    "\niti.StartsWith(\"Tech\")\t" + iti.StartsWith("Tech") +

//    "\niti.EndsWith(\"te\")\t" + iti.EndsWith("te") +
//    "\niti.EndsWith(\"gh\")\t" + iti.EndsWith("gh") +

//    "\niti.Contains(\"Cs\")\t" + iti.Contains("Cs") +
//    "\niti.Contains(\"Tech\")\t" + iti.Contains("Tech") +

//    "\niti.IndexOf('o')\t" + iti.IndexOf("o") +
//    "\niti.IndexOf('z')\t" + iti.IndexOf("z") +

//    "\niti.IndexOf(\"o\")\t" + iti.IndexOf("o") +
//    "\niti.IndexOf(\"z\")\t" + iti.IndexOf("z") +

//    "\niti.IndexOf(\"ti\")\t" + iti.IndexOf("ti") +
//    "\niti.IndexOf(\"web\")\t" + iti.IndexOf("web") 

//    );

#endregion
#region task7
//string cs = "              Computer Science              ";

//Console.WriteLine(
//    "cs\t\t\t\t: |" + cs + "|" +
//    "\ncs.TrimStart()\t\t\t: " + cs.TrimStart() + "|" +
//    "\ncs.TrimEnd()\t\t\t: " + cs.TrimEnd() + "|" +
//    "\ncs.TrimStart.TrimEnd()\t: " + cs.TrimStart().TrimEnd() + "|" +
//        "\ncs.Trim()\t\t\t: " + cs.Trim() + "|");
//string strNull = null;
//string strEmpty = string.Empty;
//string strWhiteSpace = "            ";
//string strCSharp = "C#";


//Console.WriteLine(
//    "\nstring.IsNullOrEmpty(strNull)\t\t\t\t" + string.IsNullOrEmpty(strNull) +
//    "\nstring.IsNullOrEmpty(strEmpty)\t\t\t\t" + string.IsNullOrEmpty(strEmpty) +
//    "\nstring.IsNullOrEmpty(strWhiteSpace)\t\t\t" + string.IsNullOrEmpty(strWhiteSpace) +
//    "\nstring.IsNullOrEmpty(strWhiteSpace)\t\t\t" + string.IsNullOrEmpty(strWhiteSpace.Trim()) +
//    "\nstring.IsNullOrEmpty(strCSharp)\t\t\t\t" + string.IsNullOrEmpty(strCSharp)
//    );

//Console.WriteLine(
//    "\nstring.IsNullOrEmpty(strNull)\t\t\t\t" + string.IsNullOrEmpty(strNull) +
//    "\nstring.IsNullOrEmpty(strEmpty)\t\t\t\t" + string.IsNullOrEmpty(strEmpty) +
//    "\nstring.IsNullOrEmpty(strWhiteSpace)\t\t\t" + string.IsNullOrEmpty(strWhiteSpace) +
//    "\nstring.IsNullOrEmpty(strCSharp)\t\t\t\t" + string.IsNullOrEmpty(strCSharp)
//    );
#endregion
#endregion
#region Day8
#region task1
//string iti = "MCIT Information Technology Institute";
//Console.WriteLine(
//    "iti\t\t\t: " + iti +
//    "\niti.Replace(' ','-')\t: " + iti.Replace(' ', '-') +
//    "\niti.Replace(\" \",\"-\")\t: " + iti.Replace(" ", "-") +
//    "\niti.Replace('o','O')\t: " + iti.Replace('o', 'O') +
//    "\niti.Replace(\"o\",\"O\")\t: " + iti.Replace("o", "O") +
//    "\niti.Replace(\"In \",\"iN\")\t: " + iti.Replace("In", "iN") +
//    "\niti.Replace(\"Institute \", \"Training Track\")\t: " +
//                                iti.Replace("Institute", "Training Track") +
//    "\niti.Replace(\"MCIT \", \"Egyptian Ministry of information Technology \")\t: " +
//                                iti.Replace("MCIT", "Egyptian Ministry of information Technology") +
//    "\niti.Substring(28)\t: " + iti.Substring(28) +
//    "\niti.Substring(0, 9)\t: " + iti.Substring(0, 9) +
//    "\niti.Substring(17, 4)\t: " + iti.Substring(17, 4));

#endregion
#region task2
//string str1 = "Good Morning";
//string str2 = "good morning";
//bool doesStr1EqualStr2 = str1 == str2;

//Console.WriteLine(
//    "\nstr1\t\t\t\t\t: " + str1 +
//    "\nstr2\t\t\t\t\t: " + str2 +
//    "\ndoesStr1EqualStr2\t\t\t: " + doesStr1EqualStr2 +
//    "\n(str1 == str2)\t\t\t\t: " + (str1 == str2) +
//    "\n(str1.ToUpper() == str2.ToUpper())\t: " + (str1.ToUpper() == str2.ToUpper()) +
//    "\n(str1.ToLower() == str2.ToLower())\t: " + (str1.ToLower() == str2.ToLower()));
#endregion
#region task3
//string iti = "MCIT Information Technology Institute";
//Console.WriteLine("iti\t: " + iti);

//string[] splittedIti = iti.Split(' ');
//Console.WriteLine("(((((splittedIti)))))");
//for (int i = 0; i < splittedIti.Length; i++)
//{
//    Console.WriteLine("splittedIti[" + i + "]\t: " + splittedIti[i]);
//}

//string[] summerTrainingArray = { "Web", "Development", "Using", ".NET" };

//string summerTrainingWithSpaces = string.Join(" ", summerTrainingArray);
//Console.WriteLine("\nsummerTrainingWithSpaces\t: " + summerTrainingWithSpaces);

//string summerTrainingWithHyphens = string.Join("-", summerTrainingArray);
//Console.WriteLine("summerTrainingWithHyphens\t: " + summerTrainingWithHyphens);

//char[] itiCharacters = iti.ToCharArray();
//Console.WriteLine("\n(((itiCharacters)))");
//for (int i = 0; itiCharacters.Length > 0; i++)
//    Console.WriteLine("itiCharacters[" + i + "]\t: " + itiCharacters[i]);

//char[] countryCharacters = { 'E', 'g', 'y', 'p', 't' };
//string country = string.Join(string.Empty, countryCharacters);
//Console.WriteLine("\ncountry"+country);
#endregion
#region task4
//Console.WriteLine("\n(((New Line / Line Feed)))");
//Console.WriteLine("Alexanderia\nCairo\nGiza");

//Console.WriteLine("\n(((Horizontal Tab)))");
//Console.WriteLine(
//    "Full Name\t\tAge\t\tPosition\nOmar Ashraf\t\t24\t\tDeveloper\nHossam Ali\t\t23\t\tTester");

//Console.WriteLine("\n(((Vertical Tab)))");
//string strVerticalTab = "Wel\vcome";
//Console.WriteLine(strVerticalTab);

//Console.WriteLine("\n(((Baackspace)))");
//Console.WriteLine("ABC\bDEF");
//Console.WriteLine("GHI\b\bJKL");

//Console.WriteLine("\n(((Carriago Return)))");
//Console.WriteLine("HelloBye without using Carriago Return: HelloBye");
//Console.WriteLine("Hello\rBye");

//Console.WriteLine("(((Single Quote)))");
//Console.WriteLine("How\'are\'you?");
//Console.WriteLine("How 'are' you?");


#endregion
#region task5
//Console.WriteLine("\n(((Double Qoute)))");
//Console.WriteLine("What's \"your\"name");

//Console.WriteLine("\n(((Alert)))");
//Console.WriteLine("\a");

//Console.WriteLine("\n(((Null Character)))");
//string strNullCharacter = "Wel\0come";
//Console.WriteLine(strNullCharacter);

//Console.WriteLine();
//foreach (var character in strNullCharacter)
//{
//    if (character == '\0') Console.WriteLine("[Null Character]");
//    else Console.WriteLine(character);
//}

//Console.WriteLine("(((Backslash)))");
//Console.WriteLine("E:\\Project\\Docs\\Reports");

//Console.WriteLine("(((Unicode [U    u   x])))");
//Console.WriteLine("\U000003C0");
//Console.WriteLine("\u00B6");
//Console.WriteLine("\x21");
#endregion
#region task6
//using System.Text;

//StringBuilder sbCountry = new StringBuilder();
//sbCountry.Append('E');
//sbCountry.Append('g');
//sbCountry.Append('y');
//sbCountry.Append('p');
//sbCountry.Append('t');
//Console.WriteLine("sbCountry.GetType()\t: " + sbCountry.GetType());
//Console.WriteLine(nameof(sbCountry) + "\t\t: " + sbCountry);

//StringBuilder sbAboutCompany = new StringBuilder();
//sbAboutCompany.Append('(', 5);
//sbAboutCompany.Append('*', 10);
//sbAboutCompany.Append("Bright Pearls");
//sbAboutCompany.Append('*', 10);
//sbAboutCompany.Append(')', 5);

//sbAboutCompany.AppendLine();
//sbAboutCompany.AppendLine();
//sbAboutCompany.AppendLine("Our Services:");
//sbAboutCompany.AppendLine("- Web Development,");
//sbAboutCompany.AppendLine("- Mobile Apps,");
//sbAboutCompany.AppendLine("- Desktop Development and");
//sbAboutCompany.AppendLine("-Custom Development");

//sbAboutCompany.Replace('-', '=');
//sbAboutCompany.Insert(15, ' ');
//sbAboutCompany.Insert(29, ' ');
//sbAboutCompany.Remove(10, 5);
//sbAboutCompany.Remove(25, 5);

//Console.WriteLine("sbAboutCompany[16]: " + sbAboutCompany[16]);
//sbAboutCompany[16] = 'T';
//Console.WriteLine("sbAboutCompany[16]: " + sbAboutCompany[16]);
//Console.WriteLine(nameof(sbAboutCompany) + ": " + sbAboutCompany);

//sbAboutCompany.Clear();
//Console.WriteLine("sbAboutCompany.Clear():\n" + sbAboutCompany);



#endregion
#region task7 Assignment
//DateTime dateTime1 = new DateTime(2001, 12, 30, 18, 25, 49);
//Console.WriteLine(
//    "\ndateTime1\t\t: " + dateTime1 +
//    "\ndateTime1.Date\t\t: " + dateTime1.Date +
//    "\ndateTime1.Year\t\t: " + dateTime1.Year +
//    "\ndateTime1.Month\t\t: " + dateTime1.Month +
//    "\ndateTime1.Day\t\t: " + dateTime1.Day +
//    "\ndateTime1.TimeOfDay\t: " + dateTime1.TimeOfDay +
//    "\ndateTime1.Hour\t\t: " + dateTime1.Hour +
//    "\ndateTime1.Minute\t: " + dateTime1.Minute +
//    "\ndateTime1.Second\t: " + dateTime1.Second +
//    "\n--------------------------------------" +
//    "\nDateTime.Now\t: " + DateTime.Now +
//    "\nDateTime.UtcNow\t: " + DateTime.UtcNow +
//    "\nDateTime.Today\t: " + DateTime.Today);

//DateTime dateTime2 = dateTime1.AddYears(60);
//Console.WriteLine("\ndateTime1 [dateTime1.AddYears(60)]\t: "+ dateTime2);

//DateTime dateTime3 = dateTime2.AddHours(3).AddMinutes(9).AddSeconds(22);
//Console.WriteLine("dateTime3 [dateTime2.AddHours(3).AddMinutes(9).AddSeconds(22)]\t: " + dateTime3);

//DateTime dateTime4 = DateTime.Now.AddDays(-5).AddHours(-3).AddMinutes(-2).AddSeconds(-20);
//Console.WriteLine("DateTime.Now\t: " + DateTime.Now);
//Console.WriteLine("dateTime4 [DateTime.Now.AddDays(-5).AddHours(-3).AddMinutes(-2).AddSeconds(-20)]\t: " +dateTime4);

#endregion
#endregion
#region Day9
#region task1

//using System.Runtime.CompilerServices;

//DateTime companyOpeningDateTime = new DateTime(1980, 3, 5, 10, 30, 57);
//TimeSpan tsCompanyAge1 = DateTime.Now - companyOpeningDateTime;
//Console.WriteLine("PrintTimeSpan(tsCompanyAge1)");
//PrintTimeSpan(tsCompanyAge1);

//TimeSpan tsCompanyAge2 = DateTime.Now.Subtract(companyOpeningDateTime);
//Console.WriteLine("PrintTimeSpan(tsCompanyAge2)");
//PrintTimeSpan(tsCompanyAge2);

//void PrintTimeSpan(TimeSpan timeSpan, [CallerArgumentExpression(nameof(timeSpan))] string argumentName = "")
//{
//    Console.WriteLine(
//        argumentName + "\t\t\t" + timeSpan +
//        "\n" + argumentName + "GetType()\t\t: " + timeSpan.GetType() +
//        "\n" + argumentName + "Days\t\t: " + timeSpan.Days +
//        "\n" + argumentName + "TotalDays\t\t: " + timeSpan.TotalDays +
//        "\n" + argumentName + "Hours\t\t: " + timeSpan.Hours +
//        "\n" + argumentName + "Minutes\t\t: " + timeSpan.Minutes +
//        "\n" + argumentName + "TotalMinutes\t: " + timeSpan.TotalMinutes +
//        "\n" + argumentName + "Seconds\t\t: " + timeSpan.Seconds +
//        "\n" + argumentName + "TotalSeconds\t: " + timeSpan.TotalSeconds );
//}

//TimeSpan timeSpanFromFiveDays = TimeSpan.FromDays(5);
//Console.WriteLine("timeSpanFromFiveDays\t\t: " + timeSpanFromFiveDays);

//TimeSpan timeSpanFromThreeHours = TimeSpan.FromHours(3);
//Console.WriteLine("timeSpanFromThreeHours\t\t: " + timeSpanFromThreeHours);

//TimeSpan timeSpanFrom600MillionTicks = TimeSpan.FromTicks(600_000_000);
//Console.WriteLine("timeSpanFrom600MillionTicks\t: " + timeSpanFrom600MillionTicks);

#endregion
#region task2
//string[] allogicalDrives = Directory.GetLogicalDrives();
//Console.WriteLine("(((" + nameof(allogicalDrives) + ")))");
//foreach (var logicalDrive in allogicalDrives)
//{
//    Console.WriteLine(logicalDrive);
//}

//Directory.CreateDirectory("E:\\Courses");
//Directory.CreateDirectory("E:\\Courses\\2024");
//Directory.CreateDirectory("E:\\Courses\\2025");
//Directory.CreateDirectory("E:\\Courses\\2024\\Winter");
//Directory.CreateDirectory("E:\\Courses\\2025\\Summer");

//Console.WriteLine("Directory.Exists(\"E:\\Courses\\2025\")\t: " + Directory.Exists("E:\\Courses\\2025"));
//Console.WriteLine("Directory.Exists(\"E:\\Courses\\2026\")\t: " + Directory.Exists("E:\\Courses\\2026"));

//string[] coursesSubDirectories = Directory.GetDirectories("E:\\Courses");
//Console.WriteLine("\n(((" + nameof(coursesSubDirectories) + ")))");
//foreach(string SubDirectory in coursesSubDirectories)
//{
//    Console.WriteLine(SubDirectory);
//}

//var winterParent = Directory.GetParent("E:\\Courses\\2024\\Winter");
//Console.WriteLine(nameof(winterParent) + "\t" + winterParent);

//Directory.SetCreationTime("E:\\Courses\\2024", new DateTime(2018, 8, 28, 18, 38, 48));

//DateTime courses2025CreationDateAndTime = Directory.GetCreationTime("E:\\Courses\\2024");
//Console.WriteLine(nameof(courses2025CreationDateAndTime) + "\t: " + courses2025CreationDateAndTime);

#endregion
#region task3
//File.Create("E:\\Courses\\2024\\FirstLetter.png").Dispose();

//byte[] imageAByteArray = File.ReadAllBytes("E:\\Misc Files\\A.png");
//foreach (var item in imageAByteArray)
//{
//    Console.Write(item+ " ");
//}
//File.WriteAllBytes("E:\\Courses\\2024\\FirstLetter.png", imageAByteArray);
#endregion
#region task4
//FileStream fileStreamNewImage = new FileStream("E:\\Courses\\2024\\NumberThree.png", FileMode.Create);
//FileStream fileStreamOriginalImage = new FileStream("E:\\Misc Files\\3.jpg", FileMode.Open);

//fileStreamOriginalImage.CopyTo(fileStreamNewImage);
//fileStreamNewImage.Dispose();
//fileStreamOriginalImage.Dispose();
#endregion
#region task5
//File.WriteAllText("E:\\Courses\\2024\\Greeting.txt",
//                  "Good morning!\nGood afternoon!\nGood evening!");

//string greetingsContents = File.ReadAllText("E:\\Courses\\2024\\Greeting.txt");
//Console.WriteLine("(((greetingsContents)))\n"+ greetingsContents);
#endregion
#region task6 Assignment1
//using System.Globalization;

//DateTime dateTime5 = new DateTime(1998, 12, 29, 15, 30, 57, DateTimeKind.Local);
//Console.WriteLine("new DateTime(1998, 12, 29, 15, 30, 57, DateTimeKind.Local):");
//Console.WriteLine("ar-EG: " + dateTime5.ToString(CultureInfo.CreateSpecificCulture("ar-EG")));
//Console.WriteLine("en-US: " + dateTime5.ToString(CultureInfo.CreateSpecificCulture("en-US")));
//Console.WriteLine("en-GB: " + dateTime5.ToString(CultureInfo.CreateSpecificCulture("en-GB")));

//Console.WriteLine("\ndateTime5.ToLongDateString()\t:" + dateTime5.ToLongDateString());
//Console.WriteLine("dateTime5.ToShortDateString()\t:" + dateTime5.ToShortDateString());
//Console.WriteLine("dateTime5.ToLongTimeString()\t:" + dateTime5.ToLongTimeString());
//Console.WriteLine("dateTime5.ToShortTimeString()\t:" + dateTime5.ToShortTimeString());

//Console.WriteLine("\ndateTime5.ToString(\"D\") [D-> Long Date] \t: " + dateTime5.ToString("D"));
//Console.WriteLine("\ndateTime5.ToString(\"d\") [d-> Short Date] \t: " + dateTime5.ToString("d"));
//Console.WriteLine("\ndateTime5.ToString(\"T\") [T-> Long Time] \t: " + dateTime5.ToString("T"));
//Console.WriteLine("\ndateTime5.ToString(\"T\") [T-> Short Time] \t: " + dateTime5.ToString("t"));
//Console.WriteLine("\ndateTime5.ToString(\"T\") [F-> Full Long date/time] \t: " + dateTime5.ToString("F"));
//Console.WriteLine("\ndateTime5.ToString(\"T\") [f-> full Short date/time] \t: " + dateTime5.ToString("f"));

//DateTime dateTime6 = new DateTime(1997, 8, 5, 16, 2, 3, DateTimeKind.Local);
//Console.WriteLine("\ndateTime6.ToString(\"d/M/yy H:m:s\")\t\t: " + dateTime6.ToString("d/M/yy H:m:s"));
//Console.WriteLine("\ndateTime6.ToString(\"dd/MM/yyyy HH:mm:ss\")\t: " + dateTime6.ToString("dd/MM/yyyy HH:mm:ss")); ;
//Console.WriteLine("\ndateTime6.ToString(\"d/M/yy h:m:s t\")\t: " + dateTime6.ToString("d/M/yy h:m:s t")); ;
//Console.WriteLine("\ndateTime6.ToString(\"dd/MM/yyyy hh:mm:ss tt\")\t: " + dateTime6.ToString("dd/MM/yyyy hh:mm:ss tt")); ;

//Console.WriteLine("\nDateTime.IsLeapYear(2020)\t: " + DateTime.IsLeapYear(2020));
//Console.WriteLine("DateTime.IsLeapYear(2021)\t: " + DateTime.IsLeapYear(2021));

//Console.WriteLine("DateTime.DaysInMonth(2020, 2)\t: " + DateTime.DaysInMonth(2020, 2));
//Console.WriteLine("DateTime.DaysInMonth(2021, 2)\t: " + DateTime.DaysInMonth(2021, 2));


#endregion
#region task6 Assignment2
//TimeSpan timeSpan1 = new TimeSpan();
//Console.WriteLine("timeSpan1\t\t\t\t\t: "+ timeSpan1);

//TimeSpan timeSpan2 = new TimeSpan(10_000_000);
//Console.WriteLine("timeSpan2 [ new TimeSpan(10_000_000)]\t\t: "+ timeSpan2);

//TimeSpan timeSpan3 = new TimeSpan(600_000_000);
//Console.WriteLine("timeSpan3 [ new TimeSpan(600_000_000)]\t\t: " + timeSpan3);

//TimeSpan timeSpan4 = new TimeSpan(36_000_000_000);
//Console.WriteLine("timeSpan4 [ new TimeSpan(36_000_000_000)]\t: " + timeSpan4);

//TimeSpan timeSpan5 = new TimeSpan(36_010_000_000);
//Console.WriteLine("timeSpan4 [ new TimeSpan(36_010_000_000)]\t: " + timeSpan5);

//TimeSpan timeSpan6 = new TimeSpan(10, 15, 30);
//Console.WriteLine("timeSpan4 [ new TimeSpan(10, 15, 30)]\t\t: " + timeSpan6);

//TimeSpan timeSpan7 = new TimeSpan(7, 15, 29, 41);
//Console.WriteLine("timeSpan4 [ new TimeSpan(7,15,29,41)]\t\t: " + timeSpan7);

//TimeSpan timeSpan8 = new TimeSpan(50, 25, 15, 45, 250);
//Console.WriteLine("timeSpan4 [ new TimeSpan(50, 25, 15, 45, 250)]\t: " + timeSpan8);
#endregion
#endregion
#region Day10
#region task1
//bool firstLetterExists = File.Exists("E:\\Courses\\2024\\FirstLetter.png");
//Console.WriteLine(nameof(firstLetterExists) + "\t:" + firstLetterExists);

//bool secondLetterExists = File.Exists("E:\\Courses\\2024\\SecondLetter.png");
//Console.WriteLine(nameof(secondLetterExists) + "\t:" + secondLetterExists);

//File.Copy("E:\\Courses\\2024\\FirstLetter.png", "E:\\Courses\\2025\\FirstLetterCopy.png");
//File.Move("E:\\Courses\\2024\\NumberThree.png", "E:\\Courses\\2025\\Number3.png");
//File.Delete("E:\\Courses\\2024\\Greeting.txt");

#endregion
#region task2
//File.SetCreationTime("E:\\Courses\\2024\\Track Courses.txt", new DateTime(2011, 11, 21, 11, 31, 41));
//File.SetCreationTime("E:\\Courses\\2024\\Track Courses.txt", new DateTime(2012, 12, 22, 12, 32, 42));
//File.SetCreationTime("E:\\Courses\\2024\\Track Courses.txt", new DateTime(2013, 10, 23, 13, 33, 43));

//DateTime trackCouresCreation = File.GetCreationTime("E:\\Courses\\2024\\Track Courses.txt");
//Console.WriteLine(nameof(trackCouresCreation) + "\t: " + trackCouresCreation);

//DateTime trackCouresLastWrite = File.GetLastWriteTime("E:\\Courses\\2024\\Track Courses.txt");
//Console.WriteLine(nameof(trackCouresLastWrite) + "\t: " + trackCouresLastWrite);

//DateTime trackCouresLastAccess = File.GetLastAccessTime("E:\\Courses\\2024\\Track Courses.txt");
//Console.WriteLine(nameof(trackCouresLastAccess) + "\t: " + trackCouresLastAccess);


#endregion
#region task3
//string firstLetterFullPatth = "E:\\Courses\\2024\\FirstLetter.png";
//Console.WriteLine(nameof(firstLetterFullPatth) + "\t\t: " + firstLetterFullPatth);

//string directoryName = Path.GetDirectoryName("E:\\Courses\\2024\\FirstLetter.png");
//Console.WriteLine(nameof(directoryName) + "\t\t\t: " + directoryName);

//string fileName = Path.GetFileName("E:\\Courses\\2024\\FirstLetter.png");
//Console.WriteLine(nameof(fileName) + "\t\t\t: " + fileName);

//string fileNameWithoutExtension = Path.GetFileNameWithoutExtension("E:\\Courses\\2024\\FirstLetter.png");
//Console.WriteLine(nameof(fileNameWithoutExtension) + "\t: " + fileNameWithoutExtension);

//string fileExtension = Path.GetFileNameWithoutExtension("E:\\Courses\\2024\\FirstLetter.png");
//Console.WriteLine(nameof(fileExtension) + "\t\t\t: " + fileExtension);

//string logicalDrive = "K:";
//string directory = "Schedules";
//string subDirectory = "Diplomas";
//string file = "Diplomas 129.xlsx";

//string fullPath1 = logicalDrive + "\\" + directory + "\\" + subDirectory + "\\" + file;
//Console.WriteLine(nameof(fullPath1) + "\t\t\t: " + fullPath1);

//string fullPath2 = Path.Combine(logicalDrive, directory, subDirectory, file);
//Console.WriteLine(nameof(fullPath2) + "\t\t\t: " + fullPath2);

#endregion
#region task 4 OOP
//namespace First
//{
//    public class Abc { }
//    public class Def { }
//}

//namespace Second
//{
//    using First;
//    public class Ghi 
//    {
//        Def def2;

//        void Test()
//        {
//            Def def3;
//        }
//    }
//    public class Jkl { }
//    public class Abc { }
//}
//namespace First
//{
//    public class Mno
//    {
//        Def def1;
//    }
//    public class Pqr { }

//    //The namespace 'First' already contains a definition for 'Abc'
//    //public class Abc { }
//}
#endregion
#endregion
#region Day 11
#region Last task
//Vehicle vehicle1;
//vehicle1 = new Vehicle();

////vehicle1.model= "Tiger";

////vehicle1.SetModel("Sunshine");

////vehicle1.SetModel("Emerald");
////string vehicle1Model = vehicle1.GetModel();
////Console.WriteLine(vehicle1Model);

////vehicle1.Model = "Sunshine";
//vehicle1.Model = "Emerald";
////Console.WriteLine("Aftrer setting to Sunshine-> " + vehicle1.Model);

////Console.WriteLine("Aftrer setting to Emerald-> " + vehicle1.Model);
//Console.WriteLine(nameof(vehicle1.Model)+ "\t: " + vehicle1.Model);
#endregion
#region task1
//Vehicle vehicle2 = new Vehicle();
//vehicle2.Model = "Loopard";
//vehicle2.Color = "selver";
//vehicle2.Width = 1.75f;
//vehicle2.Length = 1.68f;
//vehicle2.Height = 2.25f;
//vehicle2.MaximumSpeed = 360;

//string vehicle2Spec = vehicle2.GetSpecifiction();
//Console.WriteLine(vehicle2Spec);
//Console.WriteLine("\nvehicle2\t: "+ vehicle2);
#endregion
#region task2
//Vehicle vehicle3 = new Vehicle()
//{
//    Model = "Stars",
//    Color = "Blue",
//    Width = 1.7f,
//    Length = 2.15f,
//    Height = 1.65f,
//    MaximumSpeed = 420,
//    Engine = "SM 7"
//};

//vehicle3.MaximumSpeed = 360;

//string vehicle3Spec = vehicle3.GetSpecifications();
//Console.WriteLine(vehicle3Spec);
//Console.WriteLine("\nvehicle3\t: " + vehicle3);

//string vehicle3Spec1 = vehicle3.GetSpecifications();
//Console.WriteLine("\n vehicle3.GetSpecifications():");
//Console.WriteLine(vehicle3Spec1);

//string vehicle3Spec2Full = vehicle3.GetSpecifications("full");
//Console.WriteLine("\n vehicle3.GetSpecifications(\"full\"):");
//Console.WriteLine(vehicle3Spec2Full);

//string vehicle3Spec2Buief = vehicle3.GetSpecifications("buief");
//Console.WriteLine("\n vehicle3.GetSpecifications(\"buief\"):");
//Console.WriteLine(vehicle3Spec2Buief);

//Console.WriteLine("\nvehicle3\t: " + vehicle3);

#endregion
#region task3
//Vehicle vehicle4 = new Vehicle("Scorpion", "Black", 1.8f, 2.35f, 17.2f, 450,"TX P");

//string vehicle4Spec = vehicle4.GetSpecifications();
//Console.WriteLine(vehicle4Spec);
//Console.WriteLine("\nstring vehicle4Spec = vehicle4.GetSpecifications(): " );

//string vehicle4Spec2Full = vehicle4.GetSpecifications("full");
//Console.WriteLine("\nstring vehicle4Spec2Full = vehicle4.GetSpecifications(\"full\"):");
//Console.WriteLine(vehicle4Spec2Full);

//string vehicle4Spec2Buief = vehicle4.GetSpecifications("buief");
//Console.WriteLine("\nstring vehicle4Spec2Buief = vehicle4.GetSpecifications(\"buief\"):");
//Console.WriteLine(vehicle4Spec2Buief);
#endregion
#region task4
//Truck truck1 = new Truck("Tornado", "white", 2.85f, 6f, 3.25f, 280, "NT 3", 24f);
//string truck1Spec = truck1.GetSpecifications();
//Console.WriteLine("\nstring truck1Spec = truck1.GetSpecifications(): ");
//Console.WriteLine(truck1Spec);

//string truck1SpecFull = truck1.GetSpecifications("full");
//Console.WriteLine("\nstring truck1SpecFull = truck1.GetSpecifications(\"full\"): ");
//Console.WriteLine(truck1SpecFull);

//string truck1SpecBrief = truck1.GetSpecifications("full");
//Console.WriteLine("\nstring truck1SpecBrief = truck1.GetSpecifications(\"brief\"): ");
//Console.WriteLine(truck1SpecBrief);
#endregion
#region task5
//Truck truck7 = new Truck("Porche", "Gray", 2.85f, 6f, 3.25f, 280, "NT30", 24f);
//Console.WriteLine("truck7.ToString()");
//Console.WriteLine(truck7.ToString());
#endregion
#endregion
#region Day12
#region task1

//Truck truck7 = new Truck();
//string truck7Greeting = truck7.GreetUser("Ashraf Osama");
//Console.WriteLine("truck7Greeting: " + truck7Greeting);

#endregion
#region task2
//Customer customer1 = new Customer()
//{
//    Id = 1,
//    Name = "Lotus Group",
//    Email = "info@LotusGroup.com",
//    Address = "Cairo, 27 Alzohoor st."
//};
//Console.WriteLine(customer1.ToString());
#endregion
#region task3
//ProductDescriptionCard productDescriptionCard1 = new ProductDescriptionCard()
//{
//    Name = "Abc",
//    Size = 7,
//    Color = "Blue"
//};
//productDescriptionCard1.PrintDescription();
//ProductDescriptionCard productDescriptionCard2 = new ProductDescriptionCard("Jkl",5,"Green");
//productDescriptionCard2.PrintDescription();
#endregion
#region task4
//var train1 = new { Classificaation = "VIP", MaximumSpeed = 420, Coaches = 18 };

//Console.WriteLine("train1\t\t: " + train1.GetType());
//Console.WriteLine($"\nClassificaation\t: {train1.Classificaation}\n" +
//    $"Maximum Speed\t:  {train1.MaximumSpeed}\n" +
//    $"Coches\t\t: {train1.Coaches}");
#endregion
#region task5
//Truck truck8 = new Truck();
//Truck.Manufacturer = "Bright Stars Co.";
//Console.WriteLine("\nTruck.Manufacturer" +
//                                        Truck.Manufacturer);
//Console.WriteLine("\nTruck.GreetVisitor():");
//Truck.GreetVisitor();

//Utility.HeadOffAddress = "Giza, 31 Algomhoria st. ";
//Console.WriteLine("Utility.HeadOffAddress"+
//                                        Utility.HeadOffAddress);

//Console.WriteLine("\nUtility.PrintDate(): ");
//Utility.PrintDate();

#endregion
#region task6
//string company = "Bright Pearls";
//Console.WriteLine("company.PrintInSquareBrackets()\t: ");
//company.PrintInSquareBrackets();

//decimal projectBudget = 7500_000m;
//Console.WriteLine("\nprojectBudget\t\t\t\t\t: " + projectBudget);

//Console.Write("projectBudget.FormatAsEgyptianCurrency()\t: ");
//Console.WriteLine(projectBudget.FormatAsEgyptianCurrency());

//Console.Write("projectBudget.FormatAsBritishCurrency()\t\t: ");
//Console.WriteLine(projectBudget.FormatAsBritishCurrency());


#endregion
#endregion
#endregion
#region task2
//Nullable<int> city1Population = 750_000;
//city1Population = null;

//int? city2Population = 850_000;
//city2Population = null;

#endregion
#region Task3
while (true)
{
    try
    {
        Console.WriteLine("\nServer connection opened");
        Console.Write("Enter your age: ");
        byte age = Convert.ToByte(Console.ReadLine());
        Console.WriteLine("Age sent to the server successfully");
    }
    catch (FormatException)
    {
        Console.WriteLine("You have not entered a valid numeric format. ");
    }
    catch (OverflowException)
    {
        Console.WriteLine("You have entered a very large or small age. ");
    }
    catch (Exception ex)
    {
        Console.WriteLine(ex.Message);
    }
    finally
    {
        Console.WriteLine("Server connection closed. ");
    }
}
#endregion
