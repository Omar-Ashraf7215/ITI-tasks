﻿namespace Gem.University.Staff
{
    internal class Professor
    {
    }
}
