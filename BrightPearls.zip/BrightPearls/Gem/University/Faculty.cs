﻿//عمر اشرف محمد عبدالمجيد
//Helwan
//BIS
//Level 4
namespace Gem.University
{
    internal class Faculty
    {
    }
}
