﻿
using System.Globalization;

namespace Gem
{
    public static class ExtensionHelper
    {
        public static void PrintInSquareBrackets(this string str)
        {
            Console.WriteLine($"[[[{str}]]]");
        }
        public static string FormatAsEgyptianCurrency(this decimal amount)
        {
            return amount.ToString("C2", CultureInfo.CreateSpecificCulture("ar-EG"));
        } 
        public  static string FormatAsBritishCurrency(this decimal amount)
        {
            return amount.ToString("C2", CultureInfo.CreateSpecificCulture("en-GB"));
        }

    }
}
